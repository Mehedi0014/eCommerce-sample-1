-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2019 at 12:58 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gctl`
--

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_commentmeta`
--

CREATE TABLE `mmhs_wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_comments`
--

CREATE TABLE `mmhs_wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_comments`
--

INSERT INTO `mmhs_wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-01-15 11:17:47', '2019-01-15 11:17:47', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0),
(2, 99, 'WooCommerce', '', '', '', '2019-01-26 12:04:15', '2019-01-26 12:04:15', 'Awaiting check payment Order status changed from Pending payment to On hold.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(3, 102, 'WooCommerce', '', '', '', '2019-01-27 10:43:45', '2019-01-27 10:43:45', 'Awaiting BACS payment Order status changed from Pending payment to On hold.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(4, 103, 'WooCommerce', '', '', '', '2019-01-27 10:52:26', '2019-01-27 10:52:26', 'Awaiting BACS payment Order status changed from Pending payment to On hold.', 0, '1', 'WooCommerce', 'order_note', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_failed_jobs`
--

CREATE TABLE `mmhs_wp_failed_jobs` (
  `id` bigint(20) NOT NULL,
  `job` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_links`
--

CREATE TABLE `mmhs_wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_mailchimp_carts`
--

CREATE TABLE `mmhs_wp_mailchimp_carts` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `cart` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_options`
--

CREATE TABLE `mmhs_wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_options`
--

INSERT INTO `mmhs_wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/gctl', 'yes'),
(2, 'home', 'http://localhost/gctl', 'yes'),
(3, 'blogname', 'GCTL', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mehedi00014@gmail.com', 'yes'),
(7, 'start_of_week', '6', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:157:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=64&cpage=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:62:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$\";s:99:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]\";s:62:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:73:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:51:\"mailchimp-for-woocommerce/mailchimp-woocommerce.php\";i:1;s:21:\"megamenu/megamenu.php\";i:2;s:67:\"what-template-file-am-i-viewing/what-template-file-am-i-viewing.php\";i:3;s:27:\"woocommerce/woocommerce.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'gctl', 'yes'),
(41, 'stylesheet', 'gctl-child', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '43764', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:3:{i:1;a:0:{}i:3;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:42:\"[recent_products per_page=\"8\" columns=\"4\"]\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '64', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '43764', 'yes'),
(94, 'mmhs_wp_user_roles', 'a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:114:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:93:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:14:\"show_product_1\";a:1:{i:0;s:6:\"text-3\";}s:9:\"sidebar-1\";a:2:{i:0;s:32:\"woocommerce_product_categories-2\";i:1;s:26:\"woocommerce_price_filter-2\";}s:9:\"mega-menu\";a:3:{i:0;s:13:\"media_image-2\";i:1;s:13:\"media_image-3\";i:2;s:13:\"media_image-4\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:4:{i:2;a:16:{s:24:\"mega_menu_is_grid_widget\";s:4:\"true\";s:13:\"attachment_id\";i:73;s:3:\"url\";s:63:\"http://localhost/gctl/wp-content/uploads/2019/01/Laptop-Bag.png\";s:5:\"title\";s:10:\"Laptop Bag\";s:4:\"size\";s:4:\"full\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:34:\"http://www.facebook.com/mehedi0013\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";}i:3;a:16:{s:24:\"mega_menu_is_grid_widget\";s:4:\"true\";s:13:\"attachment_id\";i:74;s:3:\"url\";s:69:\"http://localhost/gctl/wp-content/uploads/2019/01/Mens-leather-bag.png\";s:5:\"title\";s:19:\"Men’s leather bag\";s:4:\"size\";s:4:\"full\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:1:\"#\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";}i:4;a:16:{s:24:\"mega_menu_is_grid_widget\";s:4:\"true\";s:13:\"attachment_id\";i:78;s:3:\"url\";s:67:\"http://localhost/gctl/wp-content/uploads/2019/01/PU-Leather-Bag.png\";s:5:\"title\";s:14:\"PU Leather Bag\";s:4:\"size\";s:4:\"full\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:1:\"#\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:14:{i:1553083004;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}}i:1553084268;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1553084669;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1553123868;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1553123869;a:2:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1553124718;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1553126400;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1553146318;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1553146328;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1553146763;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1553157118;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1553167097;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1554595200;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}', 'yes'),
(118, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1553081078;s:7:\"checked\";a:2:{s:10:\"gctl-child\";s:5:\"1.0.0\";s:4:\"gctl\";s:5:\"1.0.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(121, 'can_compress_scripts', '1', 'no'),
(135, 'theme_mods_twentynineteen', 'a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1547551113;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(136, 'current_theme', 'gctl Child', 'yes'),
(137, 'theme_mods_gctl', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1547555471;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(138, 'theme_switched', '', 'yes'),
(141, 'recently_activated', 'a:0:{}', 'yes'),
(150, 'woocommerce_store_address', 'Uttara, Sector 4, Road 10', 'yes'),
(151, 'woocommerce_store_address_2', '', 'yes'),
(152, 'woocommerce_store_city', 'Dhaka', 'yes'),
(153, 'woocommerce_default_country', 'BD:BD-13', 'yes'),
(154, 'woocommerce_store_postcode', '1230', 'yes'),
(155, 'woocommerce_allowed_countries', 'all', 'yes'),
(156, 'woocommerce_all_except_countries', '', 'yes'),
(157, 'woocommerce_specific_allowed_countries', '', 'yes'),
(158, 'woocommerce_ship_to_countries', '', 'yes'),
(159, 'woocommerce_specific_ship_to_countries', '', 'yes'),
(160, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(161, 'woocommerce_calc_taxes', 'no', 'yes'),
(162, 'woocommerce_enable_coupons', 'yes', 'yes'),
(163, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(164, 'woocommerce_currency', 'BDT', 'yes'),
(165, 'woocommerce_currency_pos', 'left', 'yes'),
(166, 'woocommerce_price_thousand_sep', ',', 'yes'),
(167, 'woocommerce_price_decimal_sep', '.', 'yes'),
(168, 'woocommerce_price_num_decimals', '2', 'yes'),
(169, 'woocommerce_shop_page_id', '5', 'yes'),
(170, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(171, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(172, 'woocommerce_placeholder_image', '', 'yes'),
(173, 'woocommerce_weight_unit', 'kg', 'yes'),
(174, 'woocommerce_dimension_unit', 'in', 'yes'),
(175, 'woocommerce_enable_reviews', 'yes', 'yes'),
(176, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(177, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(178, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(179, 'woocommerce_review_rating_required', 'yes', 'no'),
(180, 'woocommerce_manage_stock', 'yes', 'yes'),
(181, 'woocommerce_hold_stock_minutes', '60', 'no'),
(182, 'woocommerce_notify_low_stock', 'yes', 'no'),
(183, 'woocommerce_notify_no_stock', 'yes', 'no'),
(184, 'woocommerce_stock_email_recipient', 'mehedi00014@gmail.com', 'no'),
(185, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(186, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(187, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(188, 'woocommerce_stock_format', '', 'yes'),
(189, 'woocommerce_file_download_method', 'force', 'no'),
(190, 'woocommerce_downloads_require_login', 'no', 'no'),
(191, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(192, 'woocommerce_prices_include_tax', 'no', 'yes'),
(193, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(194, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(195, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(196, 'woocommerce_tax_classes', 'Reduced rate\r\nZero rate', 'yes'),
(197, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(198, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(199, 'woocommerce_price_display_suffix', '', 'yes'),
(200, 'woocommerce_tax_total_display', 'itemized', 'no'),
(201, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(202, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(203, 'woocommerce_ship_to_destination', 'billing', 'no'),
(204, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(205, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(206, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(207, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(208, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(209, 'woocommerce_registration_generate_username', 'yes', 'no'),
(210, 'woocommerce_registration_generate_password', 'yes', 'no'),
(211, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(212, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(213, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(214, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(215, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(216, 'woocommerce_trash_pending_orders', '', 'no'),
(217, 'woocommerce_trash_failed_orders', '', 'no'),
(218, 'woocommerce_trash_cancelled_orders', '', 'no'),
(219, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(220, 'woocommerce_email_from_name', 'GCTL', 'no'),
(221, 'woocommerce_email_from_address', 'mehedi00014@gmail.com', 'no'),
(222, 'woocommerce_email_header_image', '', 'no'),
(223, 'woocommerce_email_footer_text', '{site_title}<br/>Powered by <a href=\"https://woocommerce.com/\">WooCommerce</a>', 'no'),
(224, 'woocommerce_email_base_color', '#96588a', 'no'),
(225, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(226, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(227, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(228, 'woocommerce_cart_page_id', '6', 'yes'),
(229, 'woocommerce_checkout_page_id', '7', 'yes'),
(230, 'woocommerce_myaccount_page_id', '8', 'yes'),
(231, 'woocommerce_terms_page_id', '', 'no'),
(232, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(233, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(234, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(235, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(236, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(237, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(238, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(239, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(240, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(241, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(242, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(243, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(244, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(245, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(246, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(247, 'woocommerce_api_enabled', 'no', 'yes'),
(248, 'woocommerce_single_image_width', '600', 'yes'),
(249, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(250, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(251, 'woocommerce_demo_store', 'no', 'no'),
(252, 'woocommerce_permalinks', 'a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}', 'yes'),
(253, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(254, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(257, 'default_product_cat', '15', 'yes'),
(261, 'woocommerce_db_version', '3.5.3', 'yes'),
(262, 'woocommerce_admin_notices', 'a:2:{i:0;s:6:\"update\";i:1;s:20:\"no_secure_connection\";}', 'yes'),
(263, '_transient_woocommerce_webhook_ids', 'a:0:{}', 'yes'),
(264, 'widget_woocommerce_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(265, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(266, 'widget_woocommerce_layered_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(267, 'widget_woocommerce_price_filter', 'a:2:{i:2;a:1:{s:5:\"title\";s:15:\"Filter by price\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(268, 'widget_woocommerce_product_categories', 'a:2:{i:2;a:8:{s:5:\"title\";s:18:\"SHOP BY CATEGORIES\";s:7:\"orderby\";s:4:\"name\";s:8:\"dropdown\";i:0;s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:18:\"show_children_only\";i:0;s:10:\"hide_empty\";i:1;s:9:\"max_depth\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(269, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(270, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(271, 'widget_woocommerce_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(272, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(273, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(274, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(275, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(282, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(287, 'woocommerce_product_type', 'both', 'yes'),
(288, 'woocommerce_allow_tracking', 'no', 'yes'),
(289, 'woocommerce_cheque_settings', 'a:1:{s:7:\"enabled\";s:3:\"yes\";}', 'yes'),
(290, 'woocommerce_bacs_settings', 'a:1:{s:7:\"enabled\";s:3:\"yes\";}', 'yes'),
(291, 'woocommerce_cod_settings', 'a:1:{s:7:\"enabled\";s:3:\"yes\";}', 'yes'),
(293, '_transient_shipping-transient-version', '1547551792', 'yes'),
(295, 'mailchimp_woocommerce_plugin_do_activation_redirect', '', 'yes'),
(297, 'mailchimp_woocommerce_version', '2.1.11', 'no'),
(298, 'mailchimp-woocommerce', 'a:0:{}', 'yes'),
(300, 'mailchimp-woocommerce-store_id', '5c3dc44a8ae42', 'yes'),
(306, 'mailchimp_woocommerce_db_mailchimp_carts', '1', 'no'),
(314, '_transient_product_query-transient-version', '1548313763', 'yes'),
(315, '_transient_product-transient-version', '1548313763', 'yes'),
(321, 'product_cat_children', 'a:1:{i:16;a:3:{i:0;i:17;i:1;i:18;i:2;i:19;}}', 'yes'),
(323, '_transient_wc_attribute_taxonomies', 'a:2:{i:0;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"1\";s:14:\"attribute_name\";s:5:\"color\";s:15:\"attribute_label\";s:5:\"Color\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}i:1;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"2\";s:14:\"attribute_name\";s:4:\"size\";s:15:\"attribute_label\";s:4:\"Size\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}}', 'yes'),
(330, 'pa_size_children', 'a:0:{}', 'yes'),
(384, 'theme_mods_gctl-child', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header-menu\";i:30;}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(385, 'woocommerce_maybe_regenerate_images_hash', '991b1ca641921cf0f5baf7a2fe85861b', 'yes'),
(622, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(665, 'category_children', 'a:0:{}', 'yes'),
(717, 'widget_maxmegamenu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(718, 'megamenu_version', '2.5.3.2', 'yes'),
(719, 'megamenu_initial_version', '2.5.3.2', 'yes'),
(720, 'megamenu_multisite_share_themes', 'false', 'yes'),
(721, 'megamenu_settings', 'a:8:{s:6:\"prefix\";s:8:\"disabled\";s:12:\"descriptions\";s:7:\"enabled\";s:11:\"header-menu\";a:7:{s:7:\"enabled\";s:1:\"1\";s:5:\"event\";s:5:\"hover\";s:6:\"effect\";s:7:\"fade_up\";s:12:\"effect_speed\";s:3:\"200\";s:13:\"effect_mobile\";s:5:\"slide\";s:19:\"effect_speed_mobile\";s:3:\"200\";s:5:\"theme\";s:7:\"default\";}s:12:\"second_click\";s:5:\"close\";s:16:\"mobile_behaviour\";s:8:\"standard\";s:3:\"css\";s:2:\"fs\";s:6:\"unbind\";s:7:\"enabled\";s:9:\"instances\";a:1:{s:11:\"header-menu\";s:1:\"0\";}}', 'yes');
INSERT INTO `mmhs_wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(724, 'megamenu_themes', 'a:1:{s:7:\"default\";a:197:{s:5:\"title\";s:24:\"Custom Default Mega Menu\";s:8:\"arrow_up\";s:9:\"dash-f343\";s:10:\"arrow_down\";s:9:\"dash-f347\";s:10:\"arrow_left\";s:9:\"dash-f341\";s:11:\"arrow_right\";s:9:\"dash-f345\";s:11:\"line_height\";s:3:\"1.7\";s:7:\"z_index\";s:3:\"999\";s:17:\"shadow_horizontal\";s:3:\"0px\";s:15:\"shadow_vertical\";s:3:\"0px\";s:11:\"shadow_blur\";s:3:\"5px\";s:13:\"shadow_spread\";s:3:\"0px\";s:12:\"shadow_color\";s:18:\"rgba(0, 0, 0, 0.1)\";s:21:\"menu_item_link_height\";s:4:\"60px\";s:25:\"container_background_from\";s:15:\"rgb(0, 91, 152)\";s:23:\"container_background_to\";s:15:\"rgb(0, 91, 152)\";s:21:\"container_padding_top\";s:3:\"0px\";s:23:\"container_padding_right\";s:3:\"0px\";s:24:\"container_padding_bottom\";s:3:\"0px\";s:22:\"container_padding_left\";s:3:\"0px\";s:32:\"container_border_radius_top_left\";s:3:\"0px\";s:33:\"container_border_radius_top_right\";s:3:\"0px\";s:36:\"container_border_radius_bottom_right\";s:3:\"0px\";s:35:\"container_border_radius_bottom_left\";s:3:\"0px\";s:15:\"menu_item_align\";s:6:\"center\";s:25:\"menu_item_background_from\";s:19:\"rgba(0, 91, 152, 0)\";s:23:\"menu_item_background_to\";s:13:\"rgba(0,0,0,0)\";s:31:\"menu_item_background_hover_from\";s:19:\"rgba(34, 34, 34, 0)\";s:29:\"menu_item_background_hover_to\";s:19:\"rgba(34, 34, 34, 0)\";s:17:\"menu_item_spacing\";s:4:\"10px\";s:20:\"menu_item_link_color\";s:18:\"rgb(255, 255, 255)\";s:24:\"menu_item_link_font_size\";s:4:\"20px\";s:19:\"menu_item_link_font\";s:7:\"inherit\";s:29:\"menu_item_link_text_transform\";s:4:\"none\";s:21:\"menu_item_link_weight\";s:7:\"inherit\";s:30:\"menu_item_link_text_decoration\";s:4:\"none\";s:25:\"menu_item_link_text_align\";s:4:\"left\";s:26:\"menu_item_link_color_hover\";s:16:\"rgb(2, 247, 230)\";s:27:\"menu_item_link_weight_hover\";s:6:\"normal\";s:36:\"menu_item_link_text_decoration_hover\";s:4:\"none\";s:26:\"menu_item_link_padding_top\";s:3:\"0px\";s:28:\"menu_item_link_padding_right\";s:4:\"10px\";s:29:\"menu_item_link_padding_bottom\";s:3:\"0px\";s:27:\"menu_item_link_padding_left\";s:4:\"10px\";s:22:\"menu_item_border_color\";s:4:\"#fff\";s:20:\"menu_item_border_top\";s:3:\"0px\";s:22:\"menu_item_border_right\";s:3:\"0px\";s:23:\"menu_item_border_bottom\";s:3:\"0px\";s:21:\"menu_item_border_left\";s:3:\"0px\";s:28:\"menu_item_border_color_hover\";s:4:\"#fff\";s:37:\"menu_item_link_border_radius_top_left\";s:3:\"0px\";s:38:\"menu_item_link_border_radius_top_right\";s:3:\"0px\";s:41:\"menu_item_link_border_radius_bottom_right\";s:3:\"0px\";s:40:\"menu_item_link_border_radius_bottom_left\";s:3:\"0px\";s:23:\"menu_item_divider_color\";s:24:\"rgba(255, 255, 255, 0.1)\";s:30:\"menu_item_divider_glow_opacity\";s:3:\"0.1\";s:27:\"menu_item_highlight_current\";s:2:\"on\";s:21:\"panel_background_from\";s:7:\"#f1f1f1\";s:19:\"panel_background_to\";s:7:\"#f1f1f1\";s:11:\"panel_width\";s:3:\"50%\";s:17:\"panel_inner_width\";s:4:\"100%\";s:17:\"panel_padding_top\";s:3:\"0px\";s:19:\"panel_padding_right\";s:3:\"0px\";s:20:\"panel_padding_bottom\";s:3:\"0px\";s:18:\"panel_padding_left\";s:4:\"30px\";s:18:\"panel_border_color\";s:19:\"rgba(0, 91, 152, 0)\";s:16:\"panel_border_top\";s:3:\"2px\";s:18:\"panel_border_right\";s:3:\"2px\";s:19:\"panel_border_bottom\";s:3:\"2px\";s:17:\"panel_border_left\";s:3:\"2px\";s:28:\"panel_border_radius_top_left\";s:3:\"0px\";s:29:\"panel_border_radius_top_right\";s:3:\"0px\";s:32:\"panel_border_radius_bottom_right\";s:3:\"0px\";s:31:\"panel_border_radius_bottom_left\";s:3:\"0px\";s:24:\"panel_widget_padding_top\";s:4:\"15px\";s:26:\"panel_widget_padding_right\";s:4:\"15px\";s:27:\"panel_widget_padding_bottom\";s:4:\"15px\";s:25:\"panel_widget_padding_left\";s:4:\"15px\";s:18:\"panel_header_color\";s:4:\"#555\";s:22:\"panel_header_font_size\";s:4:\"16px\";s:17:\"panel_header_font\";s:7:\"inherit\";s:27:\"panel_header_text_transform\";s:9:\"uppercase\";s:24:\"panel_header_font_weight\";s:4:\"bold\";s:28:\"panel_header_text_decoration\";s:4:\"none\";s:24:\"panel_header_padding_top\";s:3:\"0px\";s:26:\"panel_header_padding_right\";s:3:\"0px\";s:27:\"panel_header_padding_bottom\";s:3:\"5px\";s:25:\"panel_header_padding_left\";s:3:\"0px\";s:23:\"panel_header_margin_top\";s:3:\"0px\";s:25:\"panel_header_margin_right\";s:3:\"0px\";s:26:\"panel_header_margin_bottom\";s:3:\"0px\";s:24:\"panel_header_margin_left\";s:3:\"0px\";s:25:\"panel_header_border_color\";s:4:\"#555\";s:23:\"panel_header_border_top\";s:3:\"0px\";s:25:\"panel_header_border_right\";s:3:\"0px\";s:26:\"panel_header_border_bottom\";s:3:\"0px\";s:24:\"panel_header_border_left\";s:3:\"0px\";s:16:\"panel_font_color\";s:4:\"#666\";s:15:\"panel_font_size\";s:4:\"14px\";s:17:\"panel_font_family\";s:7:\"inherit\";s:29:\"panel_second_level_font_color\";s:4:\"#555\";s:28:\"panel_second_level_font_size\";s:4:\"16px\";s:23:\"panel_second_level_font\";s:7:\"inherit\";s:33:\"panel_second_level_text_transform\";s:9:\"uppercase\";s:30:\"panel_second_level_font_weight\";s:4:\"bold\";s:34:\"panel_second_level_text_decoration\";s:4:\"none\";s:35:\"panel_second_level_font_color_hover\";s:4:\"#555\";s:36:\"panel_second_level_font_weight_hover\";s:4:\"bold\";s:40:\"panel_second_level_text_decoration_hover\";s:4:\"none\";s:40:\"panel_second_level_background_hover_from\";s:13:\"rgba(0,0,0,0)\";s:38:\"panel_second_level_background_hover_to\";s:13:\"rgba(0,0,0,0)\";s:30:\"panel_second_level_padding_top\";s:3:\"0px\";s:32:\"panel_second_level_padding_right\";s:3:\"0px\";s:33:\"panel_second_level_padding_bottom\";s:3:\"0px\";s:31:\"panel_second_level_padding_left\";s:3:\"0px\";s:29:\"panel_second_level_margin_top\";s:3:\"0px\";s:31:\"panel_second_level_margin_right\";s:3:\"0px\";s:32:\"panel_second_level_margin_bottom\";s:3:\"0px\";s:30:\"panel_second_level_margin_left\";s:3:\"0px\";s:31:\"panel_second_level_border_color\";s:4:\"#555\";s:29:\"panel_second_level_border_top\";s:3:\"0px\";s:31:\"panel_second_level_border_right\";s:3:\"0px\";s:32:\"panel_second_level_border_bottom\";s:3:\"0px\";s:30:\"panel_second_level_border_left\";s:3:\"0px\";s:28:\"panel_third_level_font_color\";s:4:\"#666\";s:27:\"panel_third_level_font_size\";s:4:\"14px\";s:22:\"panel_third_level_font\";s:7:\"inherit\";s:32:\"panel_third_level_text_transform\";s:4:\"none\";s:29:\"panel_third_level_font_weight\";s:6:\"normal\";s:33:\"panel_third_level_text_decoration\";s:4:\"none\";s:34:\"panel_third_level_font_color_hover\";s:4:\"#666\";s:35:\"panel_third_level_font_weight_hover\";s:6:\"normal\";s:39:\"panel_third_level_text_decoration_hover\";s:4:\"none\";s:39:\"panel_third_level_background_hover_from\";s:13:\"rgba(0,0,0,0)\";s:37:\"panel_third_level_background_hover_to\";s:13:\"rgba(0,0,0,0)\";s:29:\"panel_third_level_padding_top\";s:3:\"0px\";s:31:\"panel_third_level_padding_right\";s:3:\"0px\";s:32:\"panel_third_level_padding_bottom\";s:3:\"0px\";s:30:\"panel_third_level_padding_left\";s:3:\"0px\";s:27:\"flyout_menu_background_from\";s:7:\"#f1f1f1\";s:25:\"flyout_menu_background_to\";s:7:\"#f1f1f1\";s:12:\"flyout_width\";s:5:\"250px\";s:18:\"flyout_padding_top\";s:3:\"0px\";s:20:\"flyout_padding_right\";s:3:\"0px\";s:21:\"flyout_padding_bottom\";s:3:\"0px\";s:19:\"flyout_padding_left\";s:3:\"0px\";s:19:\"flyout_border_color\";s:7:\"#ffffff\";s:17:\"flyout_border_top\";s:3:\"0px\";s:19:\"flyout_border_right\";s:3:\"0px\";s:20:\"flyout_border_bottom\";s:3:\"0px\";s:18:\"flyout_border_left\";s:3:\"0px\";s:29:\"flyout_border_radius_top_left\";s:3:\"0px\";s:30:\"flyout_border_radius_top_right\";s:3:\"0px\";s:33:\"flyout_border_radius_bottom_right\";s:3:\"0px\";s:32:\"flyout_border_radius_bottom_left\";s:3:\"0px\";s:22:\"flyout_background_from\";s:7:\"#f1f1f1\";s:20:\"flyout_background_to\";s:7:\"#f1f1f1\";s:28:\"flyout_background_hover_from\";s:7:\"#dddddd\";s:26:\"flyout_background_hover_to\";s:7:\"#dddddd\";s:18:\"flyout_link_height\";s:4:\"35px\";s:23:\"flyout_link_padding_top\";s:3:\"0px\";s:25:\"flyout_link_padding_right\";s:4:\"10px\";s:26:\"flyout_link_padding_bottom\";s:3:\"0px\";s:24:\"flyout_link_padding_left\";s:4:\"10px\";s:17:\"flyout_link_color\";s:4:\"#666\";s:16:\"flyout_link_size\";s:4:\"14px\";s:18:\"flyout_link_family\";s:7:\"inherit\";s:26:\"flyout_link_text_transform\";s:4:\"none\";s:18:\"flyout_link_weight\";s:6:\"normal\";s:27:\"flyout_link_text_decoration\";s:4:\"none\";s:23:\"flyout_link_color_hover\";s:4:\"#666\";s:24:\"flyout_link_weight_hover\";s:6:\"normal\";s:33:\"flyout_link_text_decoration_hover\";s:4:\"none\";s:30:\"flyout_menu_item_divider_color\";s:24:\"rgba(255, 255, 255, 0.1)\";s:21:\"responsive_breakpoint\";s:5:\"600px\";s:22:\"toggle_background_from\";s:4:\"#222\";s:20:\"toggle_background_to\";s:4:\"#222\";s:17:\"toggle_bar_height\";s:4:\"40px\";s:32:\"mobile_menu_force_width_selector\";s:4:\"body\";s:23:\"mobile_menu_item_height\";s:4:\"40px\";s:22:\"mobile_background_from\";s:4:\"#222\";s:20:\"mobile_background_to\";s:4:\"#222\";s:38:\"mobile_menu_item_background_hover_from\";s:4:\"#333\";s:36:\"mobile_menu_item_background_hover_to\";s:4:\"#333\";s:27:\"mobile_menu_item_link_color\";s:7:\"#ffffff\";s:31:\"mobile_menu_item_link_font_size\";s:4:\"14px\";s:32:\"mobile_menu_item_link_text_align\";s:4:\"left\";s:33:\"mobile_menu_item_link_color_hover\";s:7:\"#ffffff\";s:14:\"mobile_columns\";s:1:\"1\";s:10:\"custom_css\";s:67:\"/** Push menu onto new line **/ \r\n#{$wrap} { \r\n    clear: both; \r\n}\";s:6:\"shadow\";s:3:\"off\";s:11:\"transitions\";s:3:\"off\";s:6:\"resets\";s:3:\"off\";s:17:\"menu_item_divider\";s:3:\"off\";s:24:\"flyout_menu_item_divider\";s:3:\"off\";s:21:\"disable_mobile_toggle\";s:3:\"off\";s:19:\"mobile_menu_overlay\";s:3:\"off\";s:23:\"mobile_menu_force_width\";s:3:\"off\";}}', 'yes'),
(725, 'megamenu_themes_last_updated', 'default', 'yes'),
(726, 'megamenu_toggle_blocks', 'a:1:{s:7:\"default\";a:1:{i:1;a:5:{s:4:\"type\";s:20:\"menu_toggle_animated\";s:5:\"align\";s:4:\"left\";s:5:\"style\";s:6:\"slider\";s:10:\"icon_color\";s:18:\"rgb(221, 221, 221)\";s:10:\"icon_scale\";s:3:\"0.8\";}}}', 'yes'),
(731, '_transient_megamenu_css_version', '2.5.3.2', 'yes'),
(1232, 'woocommerce_version', '3.5.4', 'yes'),
(1412, 'WPLANG', '', 'yes'),
(1413, 'new_admin_email', 'mehedi00014@gmail.com', 'yes');
INSERT INTO `mmhs_wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1452, '_transient_megamenu_css', '/** Wednesday 23rd January 2019 05:05:31 UTC (core) **/\n/** THIS FILE IS AUTOMATICALLY GENERATED - DO NOT MAKE MANUAL EDITS! **/\n/** Custom CSS should be added to Mega Menu > Menu Themes > Custom Styling **/\n\n#mega-menu-wrap-header-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-row, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-column, #mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link {\n  transition: none;\n  -webkit-border-radius: 0 0 0 0;\n  -moz-border-radius: 0 0 0 0;\n  -ms-border-radius: 0 0 0 0;\n  -o-border-radius: 0 0 0 0;\n  border-radius: 0 0 0 0;\n  -webkit-box-shadow: none;\n  -moz-box-shadow: none;\n  -ms-box-shadow: none;\n  -o-box-shadow: none;\n  box-shadow: none;\n  background: none;\n  border: 0;\n  bottom: auto;\n  box-sizing: border-box;\n  clip: auto;\n  color: #666;\n  display: block;\n  float: none;\n  font-family: inherit;\n  font-size: 14px;\n  height: auto;\n  left: auto;\n  line-height: 1.7;\n  list-style-type: none;\n  margin: 0;\n  min-height: auto;\n  max-height: none;\n  opacity: 1;\n  outline: none;\n  overflow: visible;\n  padding: 0;\n  position: relative;\n  pointer-events: auto;\n  right: auto;\n  text-align: left;\n  text-decoration: none;\n  text-transform: none;\n  transform: none;\n  top: auto;\n  vertical-align: baseline;\n  visibility: inherit;\n  width: auto;\n  word-wrap: break-word;\n}\n#mega-menu-wrap-header-menu:before, #mega-menu-wrap-header-menu #mega-menu-header-menu:before, #mega-menu-wrap-header-menu #mega-menu-header-menu ul.mega-sub-menu:before, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item:before, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-row:before, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-column:before, #mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link:before, #mega-menu-wrap-header-menu:after, #mega-menu-wrap-header-menu #mega-menu-header-menu:after, #mega-menu-wrap-header-menu #mega-menu-header-menu ul.mega-sub-menu:after, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item:after, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-row:after, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-column:after, #mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link:after {\n  display: none;\n}\n#mega-menu-wrap-header-menu {\n  -webkit-border-radius: 0px 0px 0px 0px;\n  -moz-border-radius: 0px 0px 0px 0px;\n  -ms-border-radius: 0px 0px 0px 0px;\n  -o-border-radius: 0px 0px 0px 0px;\n  border-radius: 0px 0px 0px 0px;\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu {\n    background: #005b98;\n  }\n}\n#mega-menu-wrap-header-menu.mega-keyboard-navigation .mega-menu-toggle:focus, #mega-menu-wrap-header-menu.mega-keyboard-navigation #mega-menu-header-menu a:focus, #mega-menu-wrap-header-menu.mega-keyboard-navigation #mega-menu-header-menu input:focus {\n  -webkit-box-shadow: inset 0px 0px 3px 1px #0ff;\n  -moz-box-shadow: inset 0px 0px 3px 1px #0ff;\n  -ms-box-shadow: inset 0px 0px 3px 1px #0ff;\n  -o-box-shadow: inset 0px 0px 3px 1px #0ff;\n  box-shadow: inset 0px 0px 3px 1px #0ff;\n}\n#mega-menu-wrap-header-menu.mega-keyboard-navigation > li.mega-menu-item > a.mega-menu-link:focus {\n  background: rgba(34, 34, 34, 0);\n  color: #02f7e6;\n  font-weight: normal;\n  text-decoration: none;\n  border-color: #fff;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu.mega-keyboard-navigation > li.mega-menu-item > a.mega-menu-link:focus {\n    color: #fff;\n    background: #333;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu {\n  visibility: visible;\n  text-align: center;\n  padding: 0px 0px 0px 0px;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link {\n  cursor: pointer;\n  display: inline;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link .mega-description-group {\n  vertical-align: middle;\n  display: inline-block;\n  transition: none;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link .mega-description-group .mega-menu-title, #mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link .mega-description-group .mega-menu-description {\n  transition: none;\n  line-height: 1.5;\n  display: block;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link .mega-description-group .mega-menu-description {\n  font-style: italic;\n  font-size: 0.8em;\n  text-transform: none;\n  font-weight: normal;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item.mega-icon-top > a.mega-menu-link {\n  display: table-cell;\n  vertical-align: middle;\n  line-height: initial;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item.mega-icon-top > a.mega-menu-link:before {\n  display: block;\n  margin: 0 0 6px 0;\n  text-align: center;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item.mega-icon-top > a.mega-menu-link > span.mega-title-below {\n  display: inline-block;\n  transition: none;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-icon-top > a.mega-menu-link {\n    display: block;\n    line-height: 40px;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-icon-top > a.mega-menu-link:before {\n    display: inline-block;\n    margin: 0 6px 0 0;\n    text-align: left;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item.mega-icon-right > a.mega-menu-link:before {\n  float: right;\n  margin: 0 0 0 6px;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-animating > ul.mega-sub-menu {\n  pointer-events: none;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-disable-link > a.mega-menu-link, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu li.mega-disable-link > a.mega-menu-link {\n  cursor: default;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children.mega-disable-link > a.mega-menu-link {\n  cursor: pointer;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu p {\n  margin-bottom: 10px;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu input, #mega-menu-wrap-header-menu #mega-menu-header-menu img {\n  max-width: 100%;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item > ul.mega-sub-menu {\n  display: block;\n  visibility: hidden;\n  opacity: 1;\n  pointer-events: auto;\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade\"] li.mega-menu-item > ul.mega-sub-menu {\n    opacity: 0;\n    transition: opacity 200ms ease-in, visibility 200ms ease-in;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade\"].mega-no-js li.mega-menu-item:hover > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade\"].mega-no-js li.mega-menu-item:focus > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade\"] li.mega-menu-item.mega-toggle-on > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade\"] li.mega-menu-item.mega-menu-megamenu.mega-toggle-on ul.mega-sub-menu {\n    opacity: 1;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade_up\"] li.mega-menu-item.mega-menu-megamenu > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade_up\"] li.mega-menu-item.mega-menu-flyout ul.mega-sub-menu {\n    opacity: 0;\n    transform: translate(0, 10px);\n    transition: opacity 200ms ease-in, transform 200ms ease-in, visibility 200ms ease-in;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade_up\"].mega-no-js li.mega-menu-item:hover > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade_up\"].mega-no-js li.mega-menu-item:focus > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade_up\"] li.mega-menu-item.mega-toggle-on > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"fade_up\"] li.mega-menu-item.mega-menu-megamenu.mega-toggle-on ul.mega-sub-menu {\n    opacity: 1;\n    transform: translate(0, 0);\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"slide_up\"] li.mega-menu-item.mega-menu-megamenu > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"slide_up\"] li.mega-menu-item.mega-menu-flyout ul.mega-sub-menu {\n    transform: translate(0, 10px);\n    transition: transform 200ms ease-in, visibility 200ms ease-in;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"slide_up\"].mega-no-js li.mega-menu-item:hover > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"slide_up\"].mega-no-js li.mega-menu-item:focus > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"slide_up\"] li.mega-menu-item.mega-toggle-on > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu[data-effect=\"slide_up\"] li.mega-menu-item.mega-menu-megamenu.mega-toggle-on ul.mega-sub-menu {\n    transform: translate(0, 0);\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu.mega-no-js li.mega-menu-item:hover > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu.mega-no-js li.mega-menu-item:focus > ul.mega-sub-menu, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item.mega-toggle-on > ul.mega-sub-menu {\n  visibility: visible;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item.mega-menu-megamenu ul.mega-sub-menu ul.mega-sub-menu {\n  visibility: inherit;\n  opacity: 1;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item a[class^=\'dashicons\']:before {\n  font-family: dashicons;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item a.mega-menu-link:before {\n  display: inline-block;\n  font: inherit;\n  font-family: dashicons;\n  position: static;\n  margin: 0 6px 0 0px;\n  vertical-align: top;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  color: inherit;\n  background: transparent;\n  height: auto;\n  width: auto;\n  top: auto;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item.mega-hide-text a.mega-menu-link:before {\n  margin: 0;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item.mega-hide-text li.mega-menu-item a.mega-menu-link:before {\n  margin: 0 6px 0 0;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-align-bottom-left.mega-toggle-on > a.mega-menu-link {\n  -webkit-border-radius: 0px 0px 0 0;\n  -moz-border-radius: 0px 0px 0 0;\n  -ms-border-radius: 0px 0px 0 0;\n  -o-border-radius: 0px 0px 0 0;\n  border-radius: 0px 0px 0 0;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-align-bottom-right > ul.mega-sub-menu {\n  right: 0;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-align-bottom-right.mega-toggle-on > a.mega-menu-link {\n  -webkit-border-radius: 0px 0px 0 0;\n  -moz-border-radius: 0px 0px 0 0;\n  -ms-border-radius: 0px 0px 0 0;\n  -o-border-radius: 0px 0px 0 0;\n  border-radius: 0px 0px 0 0;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu.mega-menu-item {\n  position: static;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item {\n  margin: 0 10px 0 0;\n  display: inline-block;\n  height: auto;\n  vertical-align: middle;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-item-align-right {\n  float: right;\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-item-align-right {\n    margin: 0 0 0 10px;\n  }\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-item-align-float-left {\n    float: left;\n  }\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item > a.mega-menu-link:hover {\n    background: rgba(34, 34, 34, 0);\n    color: #02f7e6;\n    font-weight: normal;\n    text-decoration: none;\n    border-color: #fff;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-toggle-on > a.mega-menu-link {\n  background: rgba(34, 34, 34, 0);\n  color: #02f7e6;\n  font-weight: normal;\n  text-decoration: none;\n  border-color: #fff;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-toggle-on > a.mega-menu-link {\n    color: #fff;\n    background: #333;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-current-menu-item > a.mega-menu-link, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-current-menu-ancestor > a.mega-menu-link, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-current-page-ancestor > a.mega-menu-link {\n  background: rgba(34, 34, 34, 0);\n  color: #02f7e6;\n  font-weight: normal;\n  text-decoration: none;\n  border-color: #fff;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-current-menu-item > a.mega-menu-link, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-current-menu-ancestor > a.mega-menu-link, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-current-page-ancestor > a.mega-menu-link {\n    color: #fff;\n    background: #333;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item > a.mega-menu-link {\n  border-top: 0px solid #fff;\n  border-left: 0px solid #fff;\n  border-right: 0px solid #fff;\n  border-bottom: 0px solid #fff;\n  outline: none;\n  text-decoration: none;\n  padding: 0px 10px 0px 10px;\n  line-height: 60px;\n  font-weight: inherit;\n  height: 60px;\n  vertical-align: baseline;\n  text-align: left;\n  width: auto;\n  display: block;\n  color: #fff;\n  text-transform: none;\n  text-decoration: none;\n  background: rgba(0, 0, 0, 0);\n  background: -webkit-gradient(linear, left top, left bottom, from(rgba(0, 91, 152, 0)), to(rgba(0, 0, 0, 0)));\n  background: -moz-linear-gradient(top, rgba(0, 91, 152, 0), rgba(0, 0, 0, 0));\n  background: -ms-linear-gradient(top, rgba(0, 91, 152, 0), rgba(0, 0, 0, 0));\n  background: -o-linear-gradient(top, rgba(0, 91, 152, 0), rgba(0, 0, 0, 0));\n  background: linear-gradient(to bottom, rgba(0, 91, 152, 0), rgba(0, 0, 0, 0));\n  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=\'#00005B98\', endColorstr=\'#00000000\');\n  -webkit-border-radius: 0px 0px 0px 0px;\n  -moz-border-radius: 0px 0px 0px 0px;\n  -ms-border-radius: 0px 0px 0px 0px;\n  -o-border-radius: 0px 0px 0px 0px;\n  border-radius: 0px 0px 0px 0px;\n  font-family: inherit;\n  font-size: 20px;\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-multi-line > a.mega-menu-link {\n    line-height: inherit;\n    display: table-cell;\n    vertical-align: middle;\n  }\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-multi-line > a.mega-menu-link br {\n    display: none;\n  }\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item {\n    display: list-item;\n    margin: 0;\n    clear: both;\n    border: 0;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item.mega-item-align-right {\n    float: none;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-item > a.mega-menu-link {\n    -webkit-border-radius: 0 0 0 0;\n    -moz-border-radius: 0 0 0 0;\n    -ms-border-radius: 0 0 0 0;\n    -o-border-radius: 0 0 0 0;\n    border-radius: 0 0 0 0;\n    border: 0;\n    margin: 0;\n    line-height: 40px;\n    height: 40px;\n    padding: 0 10px;\n    background: transparent;\n    text-align: left;\n    color: #fff;\n    font-size: 14px;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row {\n  width: 100%;\n  float: left;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row .mega-menu-column {\n  float: left;\n  min-height: 1px;\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-1 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-2 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-2 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-3 {\n    width: 33.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-3 {\n    width: 66.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-3 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-4 {\n    width: 25%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-4 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-4 {\n    width: 75%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-4 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-5 {\n    width: 20%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-5 {\n    width: 40%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-5 {\n    width: 60%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-5 {\n    width: 80%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-5-of-5 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-6 {\n    width: 16.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-6 {\n    width: 33.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-6 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-6 {\n    width: 66.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-5-of-6 {\n    width: 83.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-6-of-6 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-7 {\n    width: 14.28571%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-7 {\n    width: 28.57143%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-7 {\n    width: 42.85714%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-7 {\n    width: 57.14286%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-5-of-7 {\n    width: 71.42857%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-6-of-7 {\n    width: 85.71429%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-7-of-7 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-8 {\n    width: 12.5%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-8 {\n    width: 25%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-8 {\n    width: 37.5%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-8 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-5-of-8 {\n    width: 62.5%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-6-of-8 {\n    width: 75%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-7-of-8 {\n    width: 87.5%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-8-of-8 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-9 {\n    width: 11.11111%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-9 {\n    width: 22.22222%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-9 {\n    width: 33.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-9 {\n    width: 44.44444%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-5-of-9 {\n    width: 55.55556%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-6-of-9 {\n    width: 66.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-7-of-9 {\n    width: 77.77778%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-8-of-9 {\n    width: 88.88889%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-9-of-9 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-10 {\n    width: 10%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-10 {\n    width: 20%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-10 {\n    width: 30%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-10 {\n    width: 40%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-5-of-10 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-6-of-10 {\n    width: 60%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-7-of-10 {\n    width: 70%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-8-of-10 {\n    width: 80%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-9-of-10 {\n    width: 90%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-10-of-10 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-11 {\n    width: 9.09091%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-11 {\n    width: 18.18182%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-11 {\n    width: 27.27273%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-11 {\n    width: 36.36364%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-5-of-11 {\n    width: 45.45455%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-6-of-11 {\n    width: 54.54545%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-7-of-11 {\n    width: 63.63636%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-8-of-11 {\n    width: 72.72727%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-9-of-11 {\n    width: 81.81818%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-10-of-11 {\n    width: 90.90909%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-11-of-11 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-1-of-12 {\n    width: 8.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-2-of-12 {\n    width: 16.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-3-of-12 {\n    width: 25%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-4-of-12 {\n    width: 33.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-5-of-12 {\n    width: 41.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-6-of-12 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-7-of-12 {\n    width: 58.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-8-of-12 {\n    width: 66.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-9-of-12 {\n    width: 75%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-10-of-12 {\n    width: 83.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-11-of-12 {\n    width: 91.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-columns-12-of-12 {\n    width: 100%;\n  }\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row > ul.mega-sub-menu > li.mega-menu-column {\n    width: 100%;\n    clear: both;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-row .mega-menu-column > ul.mega-sub-menu > li.mega-menu-item {\n  padding: 15px 15px 15px 15px;\n  width: 100%;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu {\n  z-index: 999;\n  -webkit-border-radius: 0px 0px 0px 0px;\n  -moz-border-radius: 0px 0px 0px 0px;\n  -ms-border-radius: 0px 0px 0px 0px;\n  -o-border-radius: 0px 0px 0px 0px;\n  border-radius: 0px 0px 0px 0px;\n  background: #f1f1f1;\n  padding: 0px 0px 0px 30px;\n  position: absolute;\n  width: 50%;\n  border-top: 2px solid rgba(0, 91, 152, 0);\n  border-left: 2px solid rgba(0, 91, 152, 0);\n  border-right: 2px solid rgba(0, 91, 152, 0);\n  border-bottom: 2px solid rgba(0, 91, 152, 0);\n  max-width: none;\n  left: 0;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu {\n    float: left;\n    position: static;\n    width: 100%;\n  }\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-1 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-2 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-2-of-2 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-3 {\n    width: 33.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-2-of-3 {\n    width: 66.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-3-of-3 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-4 {\n    width: 25%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-2-of-4 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-3-of-4 {\n    width: 75%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-4-of-4 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-5 {\n    width: 20%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-2-of-5 {\n    width: 40%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-3-of-5 {\n    width: 60%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-4-of-5 {\n    width: 80%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-5-of-5 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-6 {\n    width: 16.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-2-of-6 {\n    width: 33.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-3-of-6 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-4-of-6 {\n    width: 66.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-5-of-6 {\n    width: 83.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-6-of-6 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-7 {\n    width: 14.28571%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-2-of-7 {\n    width: 28.57143%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-3-of-7 {\n    width: 42.85714%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-4-of-7 {\n    width: 57.14286%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-5-of-7 {\n    width: 71.42857%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-6-of-7 {\n    width: 85.71429%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-7-of-7 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-8 {\n    width: 12.5%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-2-of-8 {\n    width: 25%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-3-of-8 {\n    width: 37.5%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-4-of-8 {\n    width: 50%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-5-of-8 {\n    width: 62.5%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-6-of-8 {\n    width: 75%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-7-of-8 {\n    width: 87.5%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-8-of-8 {\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-1-of-9 {\n    width: 11.11111%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-2-of-9 {\n    width: 22.22222%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-3-of-9 {\n    width: 33.33333%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-4-of-9 {\n    width: 44.44444%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-5-of-9 {\n    width: 55.55556%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-6-of-9 {\n    width: 66.66667%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-7-of-9 {\n    width: 77.77778%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-8-of-9 {\n    width: 88.88889%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-columns-9-of-9 {\n    width: 100%;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu .mega-description-group .mega-menu-description {\n  margin: 5px 0;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item ul.mega-sub-menu {\n  clear: both;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item ul.mega-sub-menu li.mega-menu-item ul.mega-sub-menu {\n  margin-left: 10px;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu ul.mega-sub-menu ul.mega-sub-menu {\n  margin-left: 10px;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item {\n  color: #666;\n  font-family: inherit;\n  font-size: 14px;\n  display: block;\n  float: left;\n  clear: none;\n  padding: 15px 15px 15px 15px;\n  vertical-align: top;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item.mega-menu-clear, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item.mega-menu-clear {\n  clear: left;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item h4.mega-block-title, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item h4.mega-block-title {\n  color: #555;\n  font-family: inherit;\n  font-size: 16px;\n  text-transform: uppercase;\n  text-decoration: none;\n  font-weight: bold;\n  margin: 0px 0px 0px 0px;\n  padding: 0px 0px 5px 0px;\n  vertical-align: top;\n  display: block;\n  visibility: inherit;\n  border-top: 0px solid #555;\n  border-left: 0px solid #555;\n  border-right: 0px solid #555;\n  border-bottom: 0px solid #555;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link {\n  /* Mega Menu > Menu Themes > Mega Menus > Second Level Menu Items */\n  color: #555;\n  font-family: inherit;\n  font-size: 16px;\n  text-transform: uppercase;\n  text-decoration: none;\n  font-weight: bold;\n  margin: 0px 0px 0px 0px;\n  padding: 0px 0px 0px 0px;\n  vertical-align: top;\n  display: block;\n  border-top: 0px solid #555;\n  border-left: 0px solid #555;\n  border-right: 0px solid #555;\n  border-bottom: 0px solid #555;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:hover, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:hover, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:focus, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:focus {\n  /* Mega Menu > Menu Themes > Mega Menus > Second Level Menu Items (Hover) */\n  color: #555;\n  font-weight: bold;\n  text-decoration: none;\n  background: rgba(0, 0, 0, 0);\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item li.mega-menu-item > a.mega-menu-link, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item li.mega-menu-item > a.mega-menu-link {\n  /* Mega Menu > Menu Themes > Mega Menus > Third Level Menu Items */\n  color: #666;\n  font-family: inherit;\n  font-size: 14px;\n  text-transform: none;\n  text-decoration: none;\n  font-weight: normal;\n  margin: 0;\n  padding: 0px 0px 0px 0px;\n  vertical-align: top;\n  display: block;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item li.mega-menu-item > a.mega-menu-link:hover, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item li.mega-menu-item > a.mega-menu-link:hover, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item li.mega-menu-item > a.mega-menu-link:focus, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item li.mega-menu-item > a.mega-menu-link:focus {\n  /* Mega Menu > Menu Themes > Mega Menus > Third Level Menu Items (Hover) */\n  color: #666;\n  font-weight: normal;\n  text-decoration: none;\n  background: rgba(0, 0, 0, 0);\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu {\n    border: 0;\n    padding: 10px;\n    -webkit-border-radius: 0 0 0 0;\n    -moz-border-radius: 0 0 0 0;\n    -ms-border-radius: 0 0 0 0;\n    -o-border-radius: 0 0 0 0;\n    border-radius: 0 0 0 0;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-menu-item {\n    width: 100%;\n    clear: both;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu.mega-no-headers > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link {\n  color: #666;\n  font-family: inherit;\n  font-size: 14px;\n  text-transform: none;\n  text-decoration: none;\n  font-weight: normal;\n  margin: 0;\n  border: 0;\n  padding: 0px 0px 0px 0px;\n  vertical-align: top;\n  display: block;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu.mega-no-headers > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:hover, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu.mega-no-headers > ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:focus {\n  color: #666;\n  font-weight: normal;\n  text-decoration: none;\n  background: rgba(0, 0, 0, 0);\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu {\n  z-index: 999;\n  position: absolute;\n  width: 250px;\n  border-top: 0px solid #fff;\n  border-left: 0px solid #fff;\n  border-right: 0px solid #fff;\n  border-bottom: 0px solid #fff;\n  padding: 0px 0px 0px 0px;\n  background: #f1f1f1;\n  max-width: none;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu {\n    float: left;\n    position: static;\n    width: 100%;\n    padding: 0;\n    border: 0;\n  }\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item {\n    clear: both;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item a.mega-menu-link {\n  display: block;\n  background: #f1f1f1;\n  color: #666;\n  font-family: inherit;\n  font-size: 14px;\n  font-weight: normal;\n  padding: 0px 10px 0px 10px;\n  line-height: 35px;\n  text-decoration: none;\n  text-transform: none;\n  vertical-align: baseline;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item:first-child > a.mega-menu-link {\n  border-top-left-radius: 0px;\n  border-top-right-radius: 0px;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item:first-child > a.mega-menu-link {\n    border-top-left-radius: 0;\n    border-top-right-radius: 0;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item:last-child > a.mega-menu-link {\n  border-bottom-right-radius: 0px;\n  border-bottom-left-radius: 0px;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item:last-child > a.mega-menu-link {\n    border-bottom-right-radius: 0;\n    border-bottom-left-radius: 0;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item a.mega-menu-link:hover, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item a.mega-menu-link:focus {\n  background: #ddd;\n  font-weight: normal;\n  text-decoration: none;\n  color: #666;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item ul.mega-sub-menu {\n  position: absolute;\n  left: 100%;\n  top: 0;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item ul.mega-sub-menu {\n    position: static;\n    left: 0;\n    width: 100%;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-flyout ul.mega-sub-menu li.mega-menu-item ul.mega-sub-menu a.mega-menu-link {\n    padding-left: 20px;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children > a.mega-menu-link:after, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children > a.mega-menu-link span.mega-indicator:after {\n  content: \'\\f347\';\n  display: inline-block;\n  font-family: dashicons;\n  margin: 0 0 0 6px;\n  vertical-align: top;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  transform: rotate(0);\n  color: inherit;\n  position: relative;\n  background: transparent;\n  height: auto;\n  width: auto;\n  right: auto;\n  line-height: inherit;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children > a.mega-menu-link > span.mega-indicator {\n  display: none;\n  float: right;\n  height: auto;\n  width: auto;\n  background: transparent;\n  position: relative;\n  pointer-events: auto;\n  left: auto;\n  min-width: auto;\n  line-height: inherit;\n  color: inherit;\n  font-size: inherit;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children > a.mega-menu-link > span.mega-indicator:after {\n  content: \'\\f343\';\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children a.mega-menu-link:after {\n    float: right;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children.mega-toggle-on > a.mega-menu-link:after {\n    display: none;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children.mega-toggle-on > a.mega-menu-link > span.mega-indicator {\n    display: inline-block;\n  }\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children.mega-hide-sub-menu-on-mobile > a.mega-menu-link:after {\n    display: none;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-megamenu:not(.mega-menu-tabbed) li.mega-menu-item-has-children > a.mega-menu-link:after, #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item-has-children.mega-hide-arrow > a.mega-menu-link:after {\n  display: none;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item li.mega-menu-item-has-children > a.mega-menu-link:after {\n  content: \'\\f345\';\n  float: right;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-item li.mega-menu-item-has-children > a.mega-menu-link:after {\n    content: \'\\f347\';\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-flyout.mega-align-bottom-right li.mega-menu-item a.mega-menu-link {\n  text-align: right;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-flyout.mega-align-bottom-right li.mega-menu-item a.mega-menu-link {\n    text-align: left;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-flyout.mega-align-bottom-right li.mega-menu-item a.mega-menu-link:before {\n  float: right;\n  margin: 0 0 0 6px;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-flyout.mega-align-bottom-right li.mega-menu-item a.mega-menu-link:before {\n    float: left;\n    margin: 0 6px 0 0;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-flyout.mega-align-bottom-right li.mega-menu-item-has-children > a.mega-menu-link:after {\n  content: \'\\f341\';\n  float: left;\n  margin: 0;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-flyout.mega-align-bottom-right li.mega-menu-item-has-children > a.mega-menu-link:after {\n    content: \'\\f347\';\n    float: right;\n  }\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-menu-flyout.mega-align-bottom-right ul.mega-sub-menu li.mega-menu-item ul.mega-sub-menu {\n  left: -100%;\n  top: 0;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu li[class^=\'mega-lang-item\'] > a.mega-menu-link > img {\n  display: inline;\n}\n#mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link > img.wpml-ls-flag, #mega-menu-wrap-header-menu #mega-menu-header-menu a.mega-menu-link > img.iclflag {\n  display: inline;\n  margin-right: 8px;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-hide-on-mobile, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-hide-on-mobile, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item.mega-hide-on-mobile {\n    display: none;\n  }\n}\n@media only screen and (min-width: 601px) {\n  #mega-menu-wrap-header-menu #mega-menu-header-menu li.mega-hide-on-desktop, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu > li.mega-hide-on-desktop, #mega-menu-wrap-header-menu #mega-menu-header-menu > li.mega-menu-megamenu > ul.mega-sub-menu li.mega-menu-column > ul.mega-sub-menu > li.mega-menu-item.mega-hide-on-desktop {\n    display: none;\n  }\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu:after {\n    content: \"\";\n    display: table;\n    clear: both;\n  }\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle {\n  display: none;\n  z-index: 1;\n  cursor: pointer;\n  background: #222;\n  -webkit-border-radius: 2px 2px 2px 2px;\n  -moz-border-radius: 2px 2px 2px 2px;\n  -ms-border-radius: 2px 2px 2px 2px;\n  -o-border-radius: 2px 2px 2px 2px;\n  border-radius: 2px 2px 2px 2px;\n  line-height: 40px;\n  height: 40px;\n  text-align: left;\n  -webkit-touch-callout: none;\n  -webkit-user-select: none;\n  -khtml-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  -webkit-tap-highlight-color: transparent;\n  outline: none;\n  white-space: nowrap;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle img {\n  max-width: 100%;\n  padding: 0;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu .mega-menu-toggle {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: -webkit-flex;\n    display: flex;\n  }\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-left, #mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-center, #mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-right {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: -webkit-flex;\n  display: flex;\n  -ms-flex-preferred-size: 33.33%;\n  -webkit-flex-basis: 33.33%;\n  flex-basis: 33.33%;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-left {\n  -webkit-box-flex: 1;\n  -ms-flex: 1;\n  -webkit-flex: 1;\n  flex: 1;\n  -webkit-box-pack: start;\n  -ms-flex-pack: start;\n  -webkit-justify-content: flex-start;\n  justify-content: flex-start;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-left .mega-toggle-block {\n  margin-left: 6px;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-center {\n  -webkit-box-pack: center;\n  -ms-flex-pack: center;\n  -webkit-justify-content: center;\n  justify-content: center;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-center .mega-toggle-block {\n  margin-left: 3px;\n  margin-right: 3px;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-right {\n  -webkit-box-flex: 1;\n  -ms-flex: 1;\n  -webkit-flex: 1;\n  flex: 1;\n  -webkit-box-pack: end;\n  -ms-flex-pack: end;\n  -webkit-justify-content: flex-end;\n  justify-content: flex-end;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-blocks-right .mega-toggle-block {\n  margin-right: 6px;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: -webkit-flex;\n  display: flex;\n  height: 100%;\n  -webkit-align-self: center;\n  -ms-flex-item-align: center;\n  align-self: center;\n  -ms-flex-negative: 0;\n  -webkit-flex-shrink: 0;\n  flex-shrink: 0;\n}\n@media only screen and (max-width: 600px) {\n  #mega-menu-wrap-header-menu .mega-menu-toggle + #mega-menu-header-menu {\n    background: #222;\n    padding: 0;\n    display: none;\n  }\n  #mega-menu-wrap-header-menu .mega-menu-toggle + #mega-menu-header-menu li.mega-menu-item > ul.mega-sub-menu {\n    display: none;\n    visibility: visible;\n    opacity: 1;\n  }\n  #mega-menu-wrap-header-menu .mega-menu-toggle + #mega-menu-header-menu li.mega-menu-item.mega-toggle-on > ul.mega-sub-menu, #mega-menu-wrap-header-menu .mega-menu-toggle + #mega-menu-header-menu li.mega-menu-megamenu.mega-menu-item.mega-toggle-on ul.mega-sub-menu {\n    display: block;\n  }\n  #mega-menu-wrap-header-menu .mega-menu-toggle.mega-menu-open + #mega-menu-header-menu {\n    display: block;\n  }\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle {\n  /** Push menu onto new line **/\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated {\n  padding: 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: -webkit-flex;\n  display: flex;\n  cursor: pointer;\n  transition-property: opacity, filter;\n  transition-duration: 0.15s;\n  transition-timing-function: linear;\n  font: inherit;\n  color: inherit;\n  text-transform: none;\n  background-color: transparent;\n  border: 0;\n  margin: 0;\n  overflow: visible;\n  transform: scale(0.8);\n  align-self: center;\n  outline: 0;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-box {\n  width: 40px;\n  height: 24px;\n  display: inline-block;\n  position: relative;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-inner {\n  display: block;\n  top: 50%;\n  margin-top: -2px;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-inner, #mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-inner::before, #mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-inner::after {\n  width: 40px;\n  height: 4px;\n  background-color: #ddd;\n  border-radius: 4px;\n  position: absolute;\n  transition-property: transform;\n  transition-duration: 0.15s;\n  transition-timing-function: ease;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-inner::before, #mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-inner::after {\n  content: \"\";\n  display: block;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-inner::before {\n  top: -10px;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-inner::after {\n  bottom: -10px;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-slider .mega-toggle-animated-inner {\n  top: 2px;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-slider .mega-toggle-animated-inner::before {\n  top: 10px;\n  transition-property: transform, opacity;\n  transition-timing-function: ease;\n  transition-duration: 0.15s;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle .mega-toggle-block-1 .mega-toggle-animated-slider .mega-toggle-animated-inner::after {\n  top: 20px;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle.mega-menu-open .mega-toggle-block-1 .mega-toggle-animated-slider .mega-toggle-animated-inner {\n  transform: translate3d(0, 10px, 0) rotate(45deg);\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle.mega-menu-open .mega-toggle-block-1 .mega-toggle-animated-slider .mega-toggle-animated-inner::before {\n  transform: rotate(-45deg) translate3d(-5.71429px, -6px, 0);\n  opacity: 0;\n}\n#mega-menu-wrap-header-menu .mega-menu-toggle.mega-menu-open .mega-toggle-block-1 .mega-toggle-animated-slider .mega-toggle-animated-inner::after {\n  transform: translate3d(0, -20px, 0) rotate(-90deg);\n}\n#mega-menu-wrap-header-menu {\n  clear: both;\n}\n', 'yes');
INSERT INTO `mmhs_wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2067, '_transient_orders-transient-version', '1548586348', 'yes'),
(2345, '_transient_timeout_external_ip_address_::1', '1553685867', 'no'),
(2346, '_transient_external_ip_address_::1', '117.58.242.18', 'no'),
(2348, '_transient_timeout_wc_product_loop66341548313763', '1555673070', 'no'),
(2349, '_transient_wc_product_loop66341548313763', 'O:8:\"stdClass\":5:{s:3:\"ids\";a:8:{i:0;i:33;i:1;i:32;i:2;i:31;i:3;i:30;i:4;i:23;i:5;i:22;i:6;i:21;i:7;i:20;}s:5:\"total\";i:8;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:8;s:12:\"current_page\";i:1;}', 'no'),
(2350, '_transient_timeout_wc_term_counts', '1555673187', 'no'),
(2351, '_transient_wc_term_counts', 'a:6:{i:18;s:1:\"3\";i:17;s:1:\"5\";i:19;s:1:\"5\";i:16;s:2:\"14\";i:21;s:1:\"1\";i:20;s:1:\"2\";}', 'no'),
(2353, '_site_transient_timeout_theme_roots', '1553082877', 'no'),
(2354, '_site_transient_theme_roots', 'a:2:{s:10:\"gctl-child\";s:7:\"/themes\";s:4:\"gctl\";s:7:\"/themes\";}', 'no'),
(2356, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.1\";s:7:\"version\";s:5:\"5.1.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.1\";s:7:\"version\";s:5:\"5.1.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1553081092;s:15:\"version_checked\";s:5:\"5.0.4\";s:12:\"translations\";a:0:{}}', 'no'),
(2357, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1553081096;s:7:\"checked\";a:4:{s:51:\"mailchimp-for-woocommerce/mailchimp-woocommerce.php\";s:6:\"2.1.11\";s:21:\"megamenu/megamenu.php\";s:7:\"2.5.3.2\";s:67:\"what-template-file-am-i-viewing/what-template-file-am-i-viewing.php\";s:3:\"1.2\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.5.4\";}s:8:\"response\";a:3:{s:51:\"mailchimp-for-woocommerce/mailchimp-woocommerce.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:39:\"w.org/plugins/mailchimp-for-woocommerce\";s:4:\"slug\";s:25:\"mailchimp-for-woocommerce\";s:6:\"plugin\";s:51:\"mailchimp-for-woocommerce/mailchimp-woocommerce.php\";s:11:\"new_version\";s:6:\"2.1.14\";s:3:\"url\";s:56:\"https://wordpress.org/plugins/mailchimp-for-woocommerce/\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/plugin/mailchimp-for-woocommerce.2.1.14.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/mailchimp-for-woocommerce/assets/icon-256x256.png?rev=1509501\";s:2:\"1x\";s:78:\"https://ps.w.org/mailchimp-for-woocommerce/assets/icon-256x256.png?rev=1509501\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:81:\"https://ps.w.org/mailchimp-for-woocommerce/assets/banner-1544x500.png?rev=1950415\";s:2:\"1x\";s:80:\"https://ps.w.org/mailchimp-for-woocommerce/assets/banner-772x250.jpg?rev=1950415\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.0.3\";s:12:\"requires_php\";s:3:\"7.0\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:21:\"megamenu/megamenu.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:22:\"w.org/plugins/megamenu\";s:4:\"slug\";s:8:\"megamenu\";s:6:\"plugin\";s:21:\"megamenu/megamenu.php\";s:11:\"new_version\";s:3:\"2.6\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/megamenu/\";s:7:\"package\";s:55:\"https://downloads.wordpress.org/plugin/megamenu.2.6.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/megamenu/assets/icon-128x128.png?rev=1489843\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/megamenu/assets/banner-1544x500.png?rev=1933092\";s:2:\"1x\";s:63:\"https://ps.w.org/megamenu/assets/banner-772x250.png?rev=1933095\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.1.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.5.7\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.5.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.1.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:1:{s:67:\"what-template-file-am-i-viewing/what-template-file-am-i-viewing.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:45:\"w.org/plugins/what-template-file-am-i-viewing\";s:4:\"slug\";s:31:\"what-template-file-am-i-viewing\";s:6:\"plugin\";s:67:\"what-template-file-am-i-viewing/what-template-file-am-i-viewing.php\";s:11:\"new_version\";s:3:\"1.2\";s:3:\"url\";s:62:\"https://wordpress.org/plugins/what-template-file-am-i-viewing/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/what-template-file-am-i-viewing.1.2.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:82:\"https://s.w.org/plugins/geopattern-icon/what-template-file-am-i-viewing_9a9488.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:85:\"https://ps.w.org/what-template-file-am-i-viewing/assets/banner-772x250.png?rev=546775\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(2358, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:21:\"mehedi00014@gmail.com\";s:7:\"version\";s:5:\"5.0.4\";s:9:\"timestamp\";i:1553081094;}', 'no'),
(2364, '_transient_timeout_wc_product_children_11', '1555673187', 'no'),
(2365, '_transient_wc_product_children_11', 'a:2:{s:3:\"all\";a:4:{i:0;i:27;i:1;i:34;i:2;i:28;i:3;i:29;}s:7:\"visible\";a:4:{i:0;i:27;i:1;i:34;i:2;i:28;i:3;i:29;}}', 'no'),
(2366, '_transient_timeout_wc_var_prices_11', '1555673187', 'no'),
(2367, '_transient_wc_var_prices_11', '{\"version\":\"1548313763\",\"f8774becb505d4d60f906a9da31a071a\":{\"price\":{\"27\":\"42.00\",\"34\":\"45.00\",\"28\":\"45.00\",\"29\":\"45.00\"},\"regular_price\":{\"27\":\"45.00\",\"34\":\"45.00\",\"28\":\"45.00\",\"29\":\"45.00\"},\"sale_price\":{\"27\":\"42.00\",\"34\":\"45.00\",\"28\":\"45.00\",\"29\":\"45.00\"}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_postmeta`
--

CREATE TABLE `mmhs_wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_postmeta`
--

INSERT INTO `mmhs_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 3, '_wp_page_template', 'default'),
(5, 10, '_sku', 'woo-vneck-tee'),
(8, 10, '_sale_price_dates_from', ''),
(9, 10, '_sale_price_dates_to', ''),
(10, 10, 'total_sales', '0'),
(11, 10, '_tax_status', 'taxable'),
(12, 10, '_tax_class', ''),
(13, 10, '_manage_stock', 'no'),
(14, 10, '_backorders', 'no'),
(15, 10, '_low_stock_amount', ''),
(16, 10, '_sold_individually', 'no'),
(17, 10, '_weight', ''),
(18, 10, '_length', '24'),
(19, 10, '_width', '1'),
(20, 10, '_height', '2'),
(21, 10, '_upsell_ids', 'a:0:{}'),
(22, 10, '_crosssell_ids', 'a:0:{}'),
(23, 10, '_purchase_note', ''),
(24, 10, '_default_attributes', 'a:0:{}'),
(25, 10, '_virtual', 'no'),
(26, 10, '_downloadable', 'no'),
(27, 10, '_product_image_gallery', '36,37'),
(28, 10, '_download_limit', '0'),
(29, 10, '_download_expiry', '0'),
(30, 10, '_stock', NULL),
(31, 10, '_stock_status', 'instock'),
(32, 10, '_wc_average_rating', '0'),
(33, 10, '_wc_rating_count', 'a:0:{}'),
(34, 10, '_wc_review_count', '0'),
(35, 10, '_downloadable_files', 'a:0:{}'),
(36, 10, '_product_attributes', 'a:2:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}s:7:\"pa_size\";a:6:{s:4:\"name\";s:7:\"pa_size\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}}'),
(37, 10, '_product_version', '3.5.3'),
(40, 11, '_sku', 'woo-hoodie'),
(43, 11, '_sale_price_dates_from', ''),
(44, 11, '_sale_price_dates_to', ''),
(45, 11, 'total_sales', '12'),
(46, 11, '_tax_status', 'taxable'),
(47, 11, '_tax_class', ''),
(48, 11, '_manage_stock', 'no'),
(49, 11, '_backorders', 'no'),
(50, 11, '_low_stock_amount', ''),
(51, 11, '_sold_individually', 'no'),
(52, 11, '_weight', ''),
(53, 11, '_length', '10'),
(54, 11, '_width', '8'),
(55, 11, '_height', '3'),
(56, 11, '_upsell_ids', 'a:0:{}'),
(57, 11, '_crosssell_ids', 'a:0:{}'),
(58, 11, '_purchase_note', ''),
(59, 11, '_default_attributes', 'a:0:{}'),
(60, 11, '_virtual', 'no'),
(61, 11, '_downloadable', 'no'),
(62, 11, '_product_image_gallery', '39,40,41'),
(63, 11, '_download_limit', '0'),
(64, 11, '_download_expiry', '0'),
(65, 11, '_stock', NULL),
(66, 11, '_stock_status', 'instock'),
(67, 11, '_wc_average_rating', '0'),
(68, 11, '_wc_rating_count', 'a:0:{}'),
(69, 11, '_wc_review_count', '0'),
(70, 11, '_downloadable_files', 'a:0:{}'),
(71, 11, '_product_attributes', 'a:2:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}s:4:\"logo\";a:6:{s:4:\"name\";s:4:\"Logo\";s:5:\"value\";s:8:\"Yes | No\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:0;}}'),
(72, 11, '_product_version', '3.5.4'),
(75, 12, '_sku', 'woo-hoodie-with-logo'),
(76, 12, '_regular_price', '45'),
(77, 12, '_sale_price', ''),
(78, 12, '_sale_price_dates_from', ''),
(79, 12, '_sale_price_dates_to', ''),
(80, 12, 'total_sales', '6'),
(81, 12, '_tax_status', 'taxable'),
(82, 12, '_tax_class', ''),
(83, 12, '_manage_stock', 'no'),
(84, 12, '_backorders', 'no'),
(85, 12, '_low_stock_amount', ''),
(86, 12, '_sold_individually', 'no'),
(87, 12, '_weight', ''),
(88, 12, '_length', '10'),
(89, 12, '_width', '6'),
(90, 12, '_height', '3'),
(91, 12, '_upsell_ids', 'a:0:{}'),
(92, 12, '_crosssell_ids', 'a:0:{}'),
(93, 12, '_purchase_note', ''),
(94, 12, '_default_attributes', 'a:0:{}'),
(95, 12, '_virtual', 'no'),
(96, 12, '_downloadable', 'no'),
(97, 12, '_product_image_gallery', ''),
(98, 12, '_download_limit', '0'),
(99, 12, '_download_expiry', '0'),
(100, 12, '_stock', NULL),
(101, 12, '_stock_status', 'instock'),
(102, 12, '_wc_average_rating', '0'),
(103, 12, '_wc_rating_count', 'a:0:{}'),
(104, 12, '_wc_review_count', '0'),
(105, 12, '_downloadable_files', 'a:0:{}'),
(106, 12, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(107, 12, '_product_version', '3.5.3'),
(108, 12, '_price', '45'),
(110, 13, '_sku', 'woo-tshirt'),
(111, 13, '_regular_price', '18'),
(112, 13, '_sale_price', ''),
(113, 13, '_sale_price_dates_from', ''),
(114, 13, '_sale_price_dates_to', ''),
(115, 13, 'total_sales', '0'),
(116, 13, '_tax_status', 'taxable'),
(117, 13, '_tax_class', ''),
(118, 13, '_manage_stock', 'no'),
(119, 13, '_backorders', 'no'),
(120, 13, '_low_stock_amount', ''),
(121, 13, '_sold_individually', 'no'),
(122, 13, '_weight', ''),
(123, 13, '_length', '8'),
(124, 13, '_width', '6'),
(125, 13, '_height', '1'),
(126, 13, '_upsell_ids', 'a:0:{}'),
(127, 13, '_crosssell_ids', 'a:0:{}'),
(128, 13, '_purchase_note', ''),
(129, 13, '_default_attributes', 'a:0:{}'),
(130, 13, '_virtual', 'no'),
(131, 13, '_downloadable', 'no'),
(132, 13, '_product_image_gallery', ''),
(133, 13, '_download_limit', '0'),
(134, 13, '_download_expiry', '0'),
(135, 13, '_stock', NULL),
(136, 13, '_stock_status', 'instock'),
(137, 13, '_wc_average_rating', '0'),
(138, 13, '_wc_rating_count', 'a:0:{}'),
(139, 13, '_wc_review_count', '0'),
(140, 13, '_downloadable_files', 'a:0:{}'),
(141, 13, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(142, 13, '_product_version', '3.5.3'),
(143, 13, '_price', '18'),
(145, 14, '_sku', 'woo-beanie'),
(146, 14, '_regular_price', '20'),
(147, 14, '_sale_price', '18'),
(148, 14, '_sale_price_dates_from', ''),
(149, 14, '_sale_price_dates_to', ''),
(150, 14, 'total_sales', '6'),
(151, 14, '_tax_status', 'taxable'),
(152, 14, '_tax_class', ''),
(153, 14, '_manage_stock', 'no'),
(154, 14, '_backorders', 'no'),
(155, 14, '_low_stock_amount', ''),
(156, 14, '_sold_individually', 'no'),
(157, 14, '_weight', ''),
(158, 14, '_length', '4'),
(159, 14, '_width', '5'),
(160, 14, '_height', '0.5'),
(161, 14, '_upsell_ids', 'a:0:{}'),
(162, 14, '_crosssell_ids', 'a:0:{}'),
(163, 14, '_purchase_note', ''),
(164, 14, '_default_attributes', 'a:0:{}'),
(165, 14, '_virtual', 'no'),
(166, 14, '_downloadable', 'no'),
(167, 14, '_product_image_gallery', ''),
(168, 14, '_download_limit', '0'),
(169, 14, '_download_expiry', '0'),
(170, 14, '_stock', NULL),
(171, 14, '_stock_status', 'instock'),
(172, 14, '_wc_average_rating', '0'),
(173, 14, '_wc_rating_count', 'a:0:{}'),
(174, 14, '_wc_review_count', '0'),
(175, 14, '_downloadable_files', 'a:0:{}'),
(176, 14, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(177, 14, '_product_version', '3.5.3'),
(178, 14, '_price', '18'),
(180, 15, '_sku', 'woo-belt'),
(181, 15, '_regular_price', '65'),
(182, 15, '_sale_price', '55'),
(183, 15, '_sale_price_dates_from', ''),
(184, 15, '_sale_price_dates_to', ''),
(185, 15, 'total_sales', '0'),
(186, 15, '_tax_status', 'taxable'),
(187, 15, '_tax_class', ''),
(188, 15, '_manage_stock', 'no'),
(189, 15, '_backorders', 'no'),
(190, 15, '_low_stock_amount', ''),
(191, 15, '_sold_individually', 'no'),
(192, 15, '_weight', ''),
(193, 15, '_length', '12'),
(194, 15, '_width', '2'),
(195, 15, '_height', '1.5'),
(196, 15, '_upsell_ids', 'a:0:{}'),
(197, 15, '_crosssell_ids', 'a:0:{}'),
(198, 15, '_purchase_note', ''),
(199, 15, '_default_attributes', 'a:0:{}'),
(200, 15, '_virtual', 'no'),
(201, 15, '_downloadable', 'no'),
(202, 15, '_product_image_gallery', ''),
(203, 15, '_download_limit', '0'),
(204, 15, '_download_expiry', '0'),
(205, 15, '_stock', NULL),
(206, 15, '_stock_status', 'instock'),
(207, 15, '_wc_average_rating', '0'),
(208, 15, '_wc_rating_count', 'a:0:{}'),
(209, 15, '_wc_review_count', '0'),
(210, 15, '_downloadable_files', 'a:0:{}'),
(211, 15, '_product_attributes', 'a:0:{}'),
(212, 15, '_product_version', '3.5.3'),
(213, 15, '_price', '55'),
(215, 16, '_sku', 'woo-cap'),
(216, 16, '_regular_price', '18'),
(217, 16, '_sale_price', '16'),
(218, 16, '_sale_price_dates_from', ''),
(219, 16, '_sale_price_dates_to', ''),
(220, 16, 'total_sales', '2'),
(221, 16, '_tax_status', 'taxable'),
(222, 16, '_tax_class', ''),
(223, 16, '_manage_stock', 'no'),
(224, 16, '_backorders', 'no'),
(225, 16, '_low_stock_amount', ''),
(226, 16, '_sold_individually', 'no'),
(227, 16, '_weight', ''),
(228, 16, '_length', '8'),
(229, 16, '_width', '6.5'),
(230, 16, '_height', '4'),
(231, 16, '_upsell_ids', 'a:0:{}'),
(232, 16, '_crosssell_ids', 'a:0:{}'),
(233, 16, '_purchase_note', ''),
(234, 16, '_default_attributes', 'a:0:{}'),
(235, 16, '_virtual', 'no'),
(236, 16, '_downloadable', 'no'),
(237, 16, '_product_image_gallery', '56,47,55,54,53,52,51,50,49,48'),
(238, 16, '_download_limit', '0'),
(239, 16, '_download_expiry', '0'),
(240, 16, '_stock', NULL),
(241, 16, '_stock_status', 'instock'),
(242, 16, '_wc_average_rating', '0'),
(243, 16, '_wc_rating_count', 'a:0:{}'),
(244, 16, '_wc_review_count', '0'),
(245, 16, '_downloadable_files', 'a:0:{}'),
(246, 16, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(247, 16, '_product_version', '3.5.4'),
(248, 16, '_price', '16'),
(250, 17, '_sku', 'woo-sunglasses'),
(251, 17, '_regular_price', '90'),
(252, 17, '_sale_price', ''),
(253, 17, '_sale_price_dates_from', ''),
(254, 17, '_sale_price_dates_to', ''),
(255, 17, 'total_sales', '0'),
(256, 17, '_tax_status', 'taxable'),
(257, 17, '_tax_class', ''),
(258, 17, '_manage_stock', 'no'),
(259, 17, '_backorders', 'no'),
(260, 17, '_low_stock_amount', ''),
(261, 17, '_sold_individually', 'no'),
(262, 17, '_weight', ''),
(263, 17, '_length', '4'),
(264, 17, '_width', '1.4'),
(265, 17, '_height', '1'),
(266, 17, '_upsell_ids', 'a:0:{}'),
(267, 17, '_crosssell_ids', 'a:0:{}'),
(268, 17, '_purchase_note', ''),
(269, 17, '_default_attributes', 'a:0:{}'),
(270, 17, '_virtual', 'no'),
(271, 17, '_downloadable', 'no'),
(272, 17, '_product_image_gallery', ''),
(273, 17, '_download_limit', '0'),
(274, 17, '_download_expiry', '0'),
(275, 17, '_stock', NULL),
(276, 17, '_stock_status', 'instock'),
(277, 17, '_wc_average_rating', '0'),
(278, 17, '_wc_rating_count', 'a:0:{}'),
(279, 17, '_wc_review_count', '0'),
(280, 17, '_downloadable_files', 'a:0:{}'),
(281, 17, '_product_attributes', 'a:0:{}'),
(282, 17, '_product_version', '3.5.3'),
(283, 17, '_price', '90'),
(285, 18, '_sku', 'woo-hoodie-with-pocket'),
(286, 18, '_regular_price', '45'),
(287, 18, '_sale_price', '35'),
(288, 18, '_sale_price_dates_from', ''),
(289, 18, '_sale_price_dates_to', ''),
(290, 18, 'total_sales', '0'),
(291, 18, '_tax_status', 'taxable'),
(292, 18, '_tax_class', ''),
(293, 18, '_manage_stock', 'no'),
(294, 18, '_backorders', 'no'),
(295, 18, '_low_stock_amount', ''),
(296, 18, '_sold_individually', 'no'),
(297, 18, '_weight', ''),
(298, 18, '_length', '10'),
(299, 18, '_width', '8'),
(300, 18, '_height', '2'),
(301, 18, '_upsell_ids', 'a:0:{}'),
(302, 18, '_crosssell_ids', 'a:0:{}'),
(303, 18, '_purchase_note', ''),
(304, 18, '_default_attributes', 'a:0:{}'),
(305, 18, '_virtual', 'no'),
(306, 18, '_downloadable', 'no'),
(307, 18, '_product_image_gallery', ''),
(308, 18, '_download_limit', '0'),
(309, 18, '_download_expiry', '0'),
(310, 18, '_stock', NULL),
(311, 18, '_stock_status', 'instock'),
(312, 18, '_wc_average_rating', '0'),
(313, 18, '_wc_rating_count', 'a:0:{}'),
(314, 18, '_wc_review_count', '0'),
(315, 18, '_downloadable_files', 'a:0:{}'),
(316, 18, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(317, 18, '_product_version', '3.5.3'),
(318, 18, '_price', '35'),
(320, 19, '_sku', 'woo-hoodie-with-zipper'),
(321, 19, '_regular_price', '45'),
(322, 19, '_sale_price', ''),
(323, 19, '_sale_price_dates_from', ''),
(324, 19, '_sale_price_dates_to', ''),
(325, 19, 'total_sales', '0'),
(326, 19, '_tax_status', 'taxable'),
(327, 19, '_tax_class', ''),
(328, 19, '_manage_stock', 'no'),
(329, 19, '_backorders', 'no'),
(330, 19, '_low_stock_amount', ''),
(331, 19, '_sold_individually', 'no'),
(332, 19, '_weight', ''),
(333, 19, '_length', '8'),
(334, 19, '_width', '6'),
(335, 19, '_height', '2'),
(336, 19, '_upsell_ids', 'a:0:{}'),
(337, 19, '_crosssell_ids', 'a:0:{}'),
(338, 19, '_purchase_note', ''),
(339, 19, '_default_attributes', 'a:0:{}'),
(340, 19, '_virtual', 'no'),
(341, 19, '_downloadable', 'no'),
(342, 19, '_product_image_gallery', ''),
(343, 19, '_download_limit', '0'),
(344, 19, '_download_expiry', '0'),
(345, 19, '_stock', NULL),
(346, 19, '_stock_status', 'instock'),
(347, 19, '_wc_average_rating', '0'),
(348, 19, '_wc_rating_count', 'a:0:{}'),
(349, 19, '_wc_review_count', '0'),
(350, 19, '_downloadable_files', 'a:0:{}'),
(351, 19, '_product_attributes', 'a:0:{}'),
(352, 19, '_product_version', '3.5.3'),
(353, 19, '_price', '45'),
(355, 20, '_sku', 'woo-long-sleeve-tee'),
(356, 20, '_regular_price', '25'),
(357, 20, '_sale_price', ''),
(358, 20, '_sale_price_dates_from', ''),
(359, 20, '_sale_price_dates_to', ''),
(360, 20, 'total_sales', '0'),
(361, 20, '_tax_status', 'taxable'),
(362, 20, '_tax_class', ''),
(363, 20, '_manage_stock', 'no'),
(364, 20, '_backorders', 'no'),
(365, 20, '_low_stock_amount', ''),
(366, 20, '_sold_individually', 'no'),
(367, 20, '_weight', ''),
(368, 20, '_length', '7'),
(369, 20, '_width', '5'),
(370, 20, '_height', '1'),
(371, 20, '_upsell_ids', 'a:0:{}'),
(372, 20, '_crosssell_ids', 'a:0:{}'),
(373, 20, '_purchase_note', ''),
(374, 20, '_default_attributes', 'a:0:{}'),
(375, 20, '_virtual', 'no'),
(376, 20, '_downloadable', 'no'),
(377, 20, '_product_image_gallery', ''),
(378, 20, '_download_limit', '0'),
(379, 20, '_download_expiry', '0'),
(380, 20, '_stock', NULL),
(381, 20, '_stock_status', 'instock'),
(382, 20, '_wc_average_rating', '0'),
(383, 20, '_wc_rating_count', 'a:0:{}'),
(384, 20, '_wc_review_count', '0'),
(385, 20, '_downloadable_files', 'a:0:{}'),
(386, 20, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(387, 20, '_product_version', '3.5.3'),
(388, 20, '_price', '25'),
(390, 21, '_sku', 'woo-polo'),
(391, 21, '_regular_price', '20'),
(392, 21, '_sale_price', ''),
(393, 21, '_sale_price_dates_from', ''),
(394, 21, '_sale_price_dates_to', ''),
(395, 21, 'total_sales', '0'),
(396, 21, '_tax_status', 'taxable'),
(397, 21, '_tax_class', ''),
(398, 21, '_manage_stock', 'no'),
(399, 21, '_backorders', 'no'),
(400, 21, '_low_stock_amount', ''),
(401, 21, '_sold_individually', 'no'),
(402, 21, '_weight', ''),
(403, 21, '_length', '6'),
(404, 21, '_width', '5'),
(405, 21, '_height', '1'),
(406, 21, '_upsell_ids', 'a:0:{}'),
(407, 21, '_crosssell_ids', 'a:0:{}'),
(408, 21, '_purchase_note', ''),
(409, 21, '_default_attributes', 'a:0:{}'),
(410, 21, '_virtual', 'no'),
(411, 21, '_downloadable', 'no'),
(412, 21, '_product_image_gallery', ''),
(413, 21, '_download_limit', '0'),
(414, 21, '_download_expiry', '0'),
(415, 21, '_stock', NULL),
(416, 21, '_stock_status', 'instock'),
(417, 21, '_wc_average_rating', '0'),
(418, 21, '_wc_rating_count', 'a:0:{}'),
(419, 21, '_wc_review_count', '0'),
(420, 21, '_downloadable_files', 'a:0:{}'),
(421, 21, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(422, 21, '_product_version', '3.5.3'),
(423, 21, '_price', '20'),
(425, 22, '_sku', 'woo-album'),
(426, 22, '_regular_price', '15'),
(427, 22, '_sale_price', ''),
(428, 22, '_sale_price_dates_from', ''),
(429, 22, '_sale_price_dates_to', ''),
(430, 22, 'total_sales', '18'),
(431, 22, '_tax_status', 'taxable'),
(432, 22, '_tax_class', ''),
(433, 22, '_manage_stock', 'no'),
(434, 22, '_backorders', 'no'),
(435, 22, '_low_stock_amount', ''),
(436, 22, '_sold_individually', 'no'),
(437, 22, '_weight', ''),
(438, 22, '_length', ''),
(439, 22, '_width', ''),
(440, 22, '_height', ''),
(441, 22, '_upsell_ids', 'a:0:{}'),
(442, 22, '_crosssell_ids', 'a:0:{}'),
(443, 22, '_purchase_note', ''),
(444, 22, '_default_attributes', 'a:0:{}'),
(445, 22, '_virtual', 'yes'),
(446, 22, '_downloadable', 'yes'),
(447, 22, '_product_image_gallery', ''),
(448, 22, '_download_limit', '1'),
(449, 22, '_download_expiry', '1'),
(450, 22, '_stock', NULL),
(451, 22, '_stock_status', 'instock'),
(452, 22, '_wc_average_rating', '0'),
(453, 22, '_wc_rating_count', 'a:0:{}'),
(454, 22, '_wc_review_count', '0'),
(455, 22, '_downloadable_files', 'a:2:{s:36:\"ed892ee2-e4fc-4314-b62c-215ae3a38e56\";a:3:{s:2:\"id\";s:36:\"ed892ee2-e4fc-4314-b62c-215ae3a38e56\";s:4:\"name\";s:8:\"Single 1\";s:4:\"file\";s:85:\"https://demo.woothemes.com/woocommerce/wp-content/uploads/sites/56/2017/08/single.jpg\";}s:36:\"c655037e-8f27-4ae4-ab46-c989d297f9d3\";a:3:{s:2:\"id\";s:36:\"c655037e-8f27-4ae4-ab46-c989d297f9d3\";s:4:\"name\";s:8:\"Single 2\";s:4:\"file\";s:84:\"https://demo.woothemes.com/woocommerce/wp-content/uploads/sites/56/2017/08/album.jpg\";}}'),
(456, 22, '_product_attributes', 'a:0:{}'),
(457, 22, '_product_version', '3.5.3'),
(458, 22, '_price', '15'),
(460, 23, '_sku', 'woo-single'),
(461, 23, '_regular_price', '3'),
(462, 23, '_sale_price', '2'),
(463, 23, '_sale_price_dates_from', ''),
(464, 23, '_sale_price_dates_to', ''),
(465, 23, 'total_sales', '0'),
(466, 23, '_tax_status', 'taxable'),
(467, 23, '_tax_class', ''),
(468, 23, '_manage_stock', 'no'),
(469, 23, '_backorders', 'no'),
(470, 23, '_low_stock_amount', ''),
(471, 23, '_sold_individually', 'no'),
(472, 23, '_weight', ''),
(473, 23, '_length', ''),
(474, 23, '_width', ''),
(475, 23, '_height', ''),
(476, 23, '_upsell_ids', 'a:0:{}'),
(477, 23, '_crosssell_ids', 'a:0:{}'),
(478, 23, '_purchase_note', ''),
(479, 23, '_default_attributes', 'a:0:{}'),
(480, 23, '_virtual', 'yes'),
(481, 23, '_downloadable', 'yes'),
(482, 23, '_product_image_gallery', ''),
(483, 23, '_download_limit', '1'),
(484, 23, '_download_expiry', '1'),
(485, 23, '_stock', NULL),
(486, 23, '_stock_status', 'instock'),
(487, 23, '_wc_average_rating', '0'),
(488, 23, '_wc_rating_count', 'a:0:{}'),
(489, 23, '_wc_review_count', '0'),
(490, 23, '_downloadable_files', 'a:1:{s:36:\"f438e00b-f3f7-42af-85f0-03ccd20b2890\";a:3:{s:2:\"id\";s:36:\"f438e00b-f3f7-42af-85f0-03ccd20b2890\";s:4:\"name\";s:6:\"Single\";s:4:\"file\";s:85:\"https://demo.woothemes.com/woocommerce/wp-content/uploads/sites/56/2017/08/single.jpg\";}}'),
(491, 23, '_product_attributes', 'a:0:{}'),
(492, 23, '_product_version', '3.5.3'),
(493, 23, '_price', '2'),
(495, 24, '_sku', 'woo-vneck-tee-red'),
(496, 24, '_regular_price', '20'),
(497, 24, '_sale_price', ''),
(498, 24, '_sale_price_dates_from', ''),
(499, 24, '_sale_price_dates_to', ''),
(500, 24, 'total_sales', '0'),
(501, 24, '_tax_status', 'taxable'),
(502, 24, '_tax_class', ''),
(503, 24, '_manage_stock', 'no'),
(504, 24, '_backorders', 'no'),
(505, 24, '_low_stock_amount', ''),
(506, 24, '_sold_individually', 'no'),
(507, 24, '_weight', ''),
(508, 24, '_length', ''),
(509, 24, '_width', ''),
(510, 24, '_height', ''),
(511, 24, '_upsell_ids', 'a:0:{}'),
(512, 24, '_crosssell_ids', 'a:0:{}'),
(513, 24, '_purchase_note', ''),
(514, 24, '_default_attributes', 'a:0:{}'),
(515, 24, '_virtual', 'no'),
(516, 24, '_downloadable', 'no'),
(517, 24, '_product_image_gallery', ''),
(518, 24, '_download_limit', '0'),
(519, 24, '_download_expiry', '0'),
(520, 24, '_stock', NULL),
(521, 24, '_stock_status', 'instock'),
(522, 24, '_wc_average_rating', '0'),
(523, 24, '_wc_rating_count', 'a:0:{}'),
(524, 24, '_wc_review_count', '0'),
(525, 24, '_downloadable_files', 'a:0:{}'),
(526, 24, '_product_attributes', 'a:0:{}'),
(527, 24, '_product_version', '3.5.3'),
(528, 24, '_price', '20'),
(530, 25, '_sku', 'woo-vneck-tee-green'),
(531, 25, '_regular_price', '20'),
(532, 25, '_sale_price', ''),
(533, 25, '_sale_price_dates_from', ''),
(534, 25, '_sale_price_dates_to', ''),
(535, 25, 'total_sales', '0'),
(536, 25, '_tax_status', 'taxable'),
(537, 25, '_tax_class', ''),
(538, 25, '_manage_stock', 'no'),
(539, 25, '_backorders', 'no'),
(540, 25, '_low_stock_amount', ''),
(541, 25, '_sold_individually', 'no'),
(542, 25, '_weight', ''),
(543, 25, '_length', ''),
(544, 25, '_width', ''),
(545, 25, '_height', ''),
(546, 25, '_upsell_ids', 'a:0:{}'),
(547, 25, '_crosssell_ids', 'a:0:{}'),
(548, 25, '_purchase_note', ''),
(549, 25, '_default_attributes', 'a:0:{}'),
(550, 25, '_virtual', 'no'),
(551, 25, '_downloadable', 'no'),
(552, 25, '_product_image_gallery', ''),
(553, 25, '_download_limit', '0'),
(554, 25, '_download_expiry', '0'),
(555, 25, '_stock', NULL),
(556, 25, '_stock_status', 'instock'),
(557, 25, '_wc_average_rating', '0'),
(558, 25, '_wc_rating_count', 'a:0:{}'),
(559, 25, '_wc_review_count', '0'),
(560, 25, '_downloadable_files', 'a:0:{}'),
(561, 25, '_product_attributes', 'a:0:{}'),
(562, 25, '_product_version', '3.5.3'),
(563, 25, '_price', '20'),
(565, 26, '_sku', 'woo-vneck-tee-blue'),
(566, 26, '_regular_price', '15'),
(567, 26, '_sale_price', ''),
(568, 26, '_sale_price_dates_from', ''),
(569, 26, '_sale_price_dates_to', ''),
(570, 26, 'total_sales', '0'),
(571, 26, '_tax_status', 'taxable'),
(572, 26, '_tax_class', ''),
(573, 26, '_manage_stock', 'no'),
(574, 26, '_backorders', 'no'),
(575, 26, '_low_stock_amount', ''),
(576, 26, '_sold_individually', 'no'),
(577, 26, '_weight', ''),
(578, 26, '_length', ''),
(579, 26, '_width', ''),
(580, 26, '_height', ''),
(581, 26, '_upsell_ids', 'a:0:{}'),
(582, 26, '_crosssell_ids', 'a:0:{}'),
(583, 26, '_purchase_note', ''),
(584, 26, '_default_attributes', 'a:0:{}'),
(585, 26, '_virtual', 'no'),
(586, 26, '_downloadable', 'no'),
(587, 26, '_product_image_gallery', ''),
(588, 26, '_download_limit', '0'),
(589, 26, '_download_expiry', '0'),
(590, 26, '_stock', NULL),
(591, 26, '_stock_status', 'instock'),
(592, 26, '_wc_average_rating', '0'),
(593, 26, '_wc_rating_count', 'a:0:{}'),
(594, 26, '_wc_review_count', '0'),
(595, 26, '_downloadable_files', 'a:0:{}'),
(596, 26, '_product_attributes', 'a:0:{}'),
(597, 26, '_product_version', '3.5.3'),
(598, 26, '_price', '15'),
(600, 27, '_sku', 'woo-hoodie-red'),
(601, 27, '_regular_price', '45'),
(602, 27, '_sale_price', '42'),
(603, 27, '_sale_price_dates_from', ''),
(604, 27, '_sale_price_dates_to', ''),
(605, 27, 'total_sales', '0'),
(606, 27, '_tax_status', 'taxable'),
(607, 27, '_tax_class', ''),
(608, 27, '_manage_stock', 'no'),
(609, 27, '_backorders', 'no'),
(610, 27, '_low_stock_amount', ''),
(611, 27, '_sold_individually', 'no'),
(612, 27, '_weight', ''),
(613, 27, '_length', ''),
(614, 27, '_width', ''),
(615, 27, '_height', ''),
(616, 27, '_upsell_ids', 'a:0:{}'),
(617, 27, '_crosssell_ids', 'a:0:{}'),
(618, 27, '_purchase_note', ''),
(619, 27, '_default_attributes', 'a:0:{}'),
(620, 27, '_virtual', 'no'),
(621, 27, '_downloadable', 'no'),
(622, 27, '_product_image_gallery', ''),
(623, 27, '_download_limit', '0'),
(624, 27, '_download_expiry', '0'),
(625, 27, '_stock', NULL),
(626, 27, '_stock_status', 'instock'),
(627, 27, '_wc_average_rating', '0'),
(628, 27, '_wc_rating_count', 'a:0:{}'),
(629, 27, '_wc_review_count', '0'),
(630, 27, '_downloadable_files', 'a:0:{}'),
(631, 27, '_product_attributes', 'a:0:{}'),
(632, 27, '_product_version', '3.5.4'),
(633, 27, '_price', '42'),
(635, 28, '_sku', 'woo-hoodie-green'),
(636, 28, '_regular_price', '45'),
(637, 28, '_sale_price', ''),
(638, 28, '_sale_price_dates_from', ''),
(639, 28, '_sale_price_dates_to', ''),
(640, 28, 'total_sales', '0'),
(641, 28, '_tax_status', 'taxable'),
(642, 28, '_tax_class', ''),
(643, 28, '_manage_stock', 'no'),
(644, 28, '_backorders', 'no'),
(645, 28, '_low_stock_amount', ''),
(646, 28, '_sold_individually', 'no'),
(647, 28, '_weight', ''),
(648, 28, '_length', ''),
(649, 28, '_width', ''),
(650, 28, '_height', ''),
(651, 28, '_upsell_ids', 'a:0:{}'),
(652, 28, '_crosssell_ids', 'a:0:{}'),
(653, 28, '_purchase_note', ''),
(654, 28, '_default_attributes', 'a:0:{}'),
(655, 28, '_virtual', 'no'),
(656, 28, '_downloadable', 'no'),
(657, 28, '_product_image_gallery', ''),
(658, 28, '_download_limit', '0'),
(659, 28, '_download_expiry', '0'),
(660, 28, '_stock', NULL),
(661, 28, '_stock_status', 'instock'),
(662, 28, '_wc_average_rating', '0'),
(663, 28, '_wc_rating_count', 'a:0:{}'),
(664, 28, '_wc_review_count', '0'),
(665, 28, '_downloadable_files', 'a:0:{}'),
(666, 28, '_product_attributes', 'a:0:{}'),
(667, 28, '_product_version', '3.5.3'),
(668, 28, '_price', '45'),
(670, 29, '_sku', 'woo-hoodie-blue'),
(671, 29, '_regular_price', '45'),
(672, 29, '_sale_price', ''),
(673, 29, '_sale_price_dates_from', ''),
(674, 29, '_sale_price_dates_to', ''),
(675, 29, 'total_sales', '0'),
(676, 29, '_tax_status', 'taxable'),
(677, 29, '_tax_class', ''),
(678, 29, '_manage_stock', 'no'),
(679, 29, '_backorders', 'no'),
(680, 29, '_low_stock_amount', ''),
(681, 29, '_sold_individually', 'no'),
(682, 29, '_weight', ''),
(683, 29, '_length', ''),
(684, 29, '_width', ''),
(685, 29, '_height', ''),
(686, 29, '_upsell_ids', 'a:0:{}'),
(687, 29, '_crosssell_ids', 'a:0:{}'),
(688, 29, '_purchase_note', ''),
(689, 29, '_default_attributes', 'a:0:{}'),
(690, 29, '_virtual', 'no'),
(691, 29, '_downloadable', 'no'),
(692, 29, '_product_image_gallery', ''),
(693, 29, '_download_limit', '0'),
(694, 29, '_download_expiry', '0'),
(695, 29, '_stock', NULL),
(696, 29, '_stock_status', 'instock'),
(697, 29, '_wc_average_rating', '0'),
(698, 29, '_wc_rating_count', 'a:0:{}'),
(699, 29, '_wc_review_count', '0'),
(700, 29, '_downloadable_files', 'a:0:{}'),
(701, 29, '_product_attributes', 'a:0:{}'),
(702, 29, '_product_version', '3.5.3'),
(703, 29, '_price', '45'),
(705, 30, '_sku', 'Woo-tshirt-logo'),
(706, 30, '_regular_price', '18'),
(707, 30, '_sale_price', ''),
(708, 30, '_sale_price_dates_from', ''),
(709, 30, '_sale_price_dates_to', ''),
(710, 30, 'total_sales', '0'),
(711, 30, '_tax_status', 'taxable'),
(712, 30, '_tax_class', ''),
(713, 30, '_manage_stock', 'no'),
(714, 30, '_backorders', 'no'),
(715, 30, '_low_stock_amount', ''),
(716, 30, '_sold_individually', 'no'),
(717, 30, '_weight', ''),
(718, 30, '_length', '10'),
(719, 30, '_width', '12'),
(720, 30, '_height', '0.5'),
(721, 30, '_upsell_ids', 'a:0:{}'),
(722, 30, '_crosssell_ids', 'a:0:{}'),
(723, 30, '_purchase_note', ''),
(724, 30, '_default_attributes', 'a:0:{}'),
(725, 30, '_virtual', 'no'),
(726, 30, '_downloadable', 'no'),
(727, 30, '_product_image_gallery', ''),
(728, 30, '_download_limit', '0'),
(729, 30, '_download_expiry', '0'),
(730, 30, '_stock', NULL),
(731, 30, '_stock_status', 'instock'),
(732, 30, '_wc_average_rating', '0'),
(733, 30, '_wc_rating_count', 'a:0:{}'),
(734, 30, '_wc_review_count', '0'),
(735, 30, '_downloadable_files', 'a:0:{}'),
(736, 30, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(737, 30, '_product_version', '3.5.3'),
(738, 30, '_price', '18'),
(740, 31, '_sku', 'Woo-beanie-logo'),
(741, 31, '_regular_price', '20'),
(742, 31, '_sale_price', '18'),
(743, 31, '_sale_price_dates_from', ''),
(744, 31, '_sale_price_dates_to', ''),
(745, 31, 'total_sales', '6'),
(746, 31, '_tax_status', 'taxable'),
(747, 31, '_tax_class', ''),
(748, 31, '_manage_stock', 'no'),
(749, 31, '_backorders', 'no'),
(750, 31, '_low_stock_amount', ''),
(751, 31, '_sold_individually', 'no'),
(752, 31, '_weight', ''),
(753, 31, '_length', '6'),
(754, 31, '_width', '4'),
(755, 31, '_height', '1'),
(756, 31, '_upsell_ids', 'a:0:{}'),
(757, 31, '_crosssell_ids', 'a:0:{}'),
(758, 31, '_purchase_note', ''),
(759, 31, '_default_attributes', 'a:0:{}'),
(760, 31, '_virtual', 'no'),
(761, 31, '_downloadable', 'no'),
(762, 31, '_product_image_gallery', ''),
(763, 31, '_download_limit', '0'),
(764, 31, '_download_expiry', '0'),
(765, 31, '_stock', NULL),
(766, 31, '_stock_status', 'instock'),
(767, 31, '_wc_average_rating', '0'),
(768, 31, '_wc_rating_count', 'a:0:{}'),
(769, 31, '_wc_review_count', '0'),
(770, 31, '_downloadable_files', 'a:0:{}'),
(771, 31, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:0;s:11:\"is_taxonomy\";i:1;}}'),
(772, 31, '_product_version', '3.5.3'),
(773, 31, '_price', '18'),
(775, 32, '_sku', 'logo-collection'),
(778, 32, '_sale_price_dates_from', ''),
(779, 32, '_sale_price_dates_to', ''),
(780, 32, 'total_sales', '0'),
(781, 32, '_tax_status', 'taxable'),
(782, 32, '_tax_class', ''),
(783, 32, '_manage_stock', 'no'),
(784, 32, '_backorders', 'no'),
(785, 32, '_low_stock_amount', ''),
(786, 32, '_sold_individually', 'no'),
(787, 32, '_weight', ''),
(788, 32, '_length', ''),
(789, 32, '_width', ''),
(790, 32, '_height', ''),
(791, 32, '_upsell_ids', 'a:0:{}'),
(792, 32, '_crosssell_ids', 'a:0:{}'),
(793, 32, '_purchase_note', ''),
(794, 32, '_default_attributes', 'a:0:{}'),
(795, 32, '_virtual', 'no'),
(796, 32, '_downloadable', 'no'),
(797, 32, '_product_image_gallery', '54,53,41'),
(798, 32, '_download_limit', '0'),
(799, 32, '_download_expiry', '0'),
(800, 32, '_stock', NULL),
(801, 32, '_stock_status', 'instock'),
(802, 32, '_wc_average_rating', '0'),
(803, 32, '_wc_rating_count', 'a:0:{}'),
(804, 32, '_wc_review_count', '0'),
(805, 32, '_downloadable_files', 'a:0:{}'),
(806, 32, '_product_attributes', 'a:0:{}'),
(807, 32, '_product_version', '3.5.3'),
(810, 33, '_sku', 'wp-pennant'),
(811, 33, '_regular_price', '11.05'),
(812, 33, '_sale_price', ''),
(813, 33, '_sale_price_dates_from', ''),
(814, 33, '_sale_price_dates_to', ''),
(815, 33, 'total_sales', '0'),
(816, 33, '_tax_status', 'taxable'),
(817, 33, '_tax_class', ''),
(818, 33, '_manage_stock', 'no'),
(819, 33, '_backorders', 'no'),
(820, 33, '_low_stock_amount', ''),
(821, 33, '_sold_individually', 'no'),
(822, 33, '_weight', ''),
(823, 33, '_length', ''),
(824, 33, '_width', ''),
(825, 33, '_height', ''),
(826, 33, '_upsell_ids', 'a:0:{}'),
(827, 33, '_crosssell_ids', 'a:0:{}'),
(828, 33, '_purchase_note', ''),
(829, 33, '_default_attributes', 'a:0:{}'),
(830, 33, '_virtual', 'no'),
(831, 33, '_downloadable', 'no'),
(832, 33, '_product_image_gallery', ''),
(833, 33, '_download_limit', '0'),
(834, 33, '_download_expiry', '0'),
(835, 33, '_stock', NULL),
(836, 33, '_stock_status', 'instock'),
(837, 33, '_wc_average_rating', '0'),
(838, 33, '_wc_rating_count', 'a:0:{}'),
(839, 33, '_wc_review_count', '0'),
(840, 33, '_downloadable_files', 'a:0:{}'),
(841, 33, '_product_attributes', 'a:0:{}'),
(842, 33, '_product_version', '3.5.4'),
(843, 33, '_price', '11.05'),
(845, 34, '_sku', 'woo-hoodie-blue-logo'),
(846, 34, '_regular_price', '45'),
(847, 34, '_sale_price', ''),
(848, 34, '_sale_price_dates_from', ''),
(849, 34, '_sale_price_dates_to', ''),
(850, 34, 'total_sales', '0'),
(851, 34, '_tax_status', 'taxable'),
(852, 34, '_tax_class', ''),
(853, 34, '_manage_stock', 'no'),
(854, 34, '_backorders', 'no'),
(855, 34, '_low_stock_amount', ''),
(856, 34, '_sold_individually', 'no'),
(857, 34, '_weight', ''),
(858, 34, '_length', ''),
(859, 34, '_width', ''),
(860, 34, '_height', ''),
(861, 34, '_upsell_ids', 'a:0:{}'),
(862, 34, '_crosssell_ids', 'a:0:{}'),
(863, 34, '_purchase_note', ''),
(864, 34, '_default_attributes', 'a:0:{}'),
(865, 34, '_virtual', 'no'),
(866, 34, '_downloadable', 'no'),
(867, 34, '_product_image_gallery', ''),
(868, 34, '_download_limit', '0'),
(869, 34, '_download_expiry', '0'),
(870, 34, '_stock', NULL),
(871, 34, '_stock_status', 'instock'),
(872, 34, '_wc_average_rating', '0'),
(873, 34, '_wc_rating_count', 'a:0:{}'),
(874, 34, '_wc_review_count', '0'),
(875, 34, '_downloadable_files', 'a:0:{}'),
(876, 34, '_product_attributes', 'a:0:{}'),
(877, 34, '_product_version', '3.5.3'),
(878, 34, '_price', '45'),
(880, 35, '_wp_attached_file', '2019/01/vneck-tee-2.jpg'),
(881, 35, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2019/01/vneck-tee-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(882, 35, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vneck-tee-2.jpg'),
(883, 36, '_wp_attached_file', '2019/01/vnech-tee-green-1.jpg'),
(884, 36, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:29:\"2019/01/vnech-tee-green-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(885, 36, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vnech-tee-green-1.jpg'),
(886, 37, '_wp_attached_file', '2019/01/vnech-tee-blue-1.jpg'),
(887, 37, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:28:\"2019/01/vnech-tee-blue-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(888, 37, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vnech-tee-blue-1.jpg'),
(889, 10, '_wpcom_is_markdown', '1'),
(890, 10, '_wp_old_slug', 'import-placeholder-for-44'),
(891, 10, '_thumbnail_id', '35'),
(892, 38, '_wp_attached_file', '2019/01/hoodie-2.jpg'),
(893, 38, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2019/01/hoodie-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"hoodie-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"hoodie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"hoodie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(894, 38, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-2.jpg'),
(895, 39, '_wp_attached_file', '2019/01/hoodie-blue-1.jpg'),
(896, 39, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:25:\"2019/01/hoodie-blue-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(897, 39, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-blue-1.jpg'),
(898, 40, '_wp_attached_file', '2019/01/hoodie-green-1.jpg'),
(899, 40, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:26:\"2019/01/hoodie-green-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(900, 40, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-green-1.jpg'),
(901, 41, '_wp_attached_file', '2019/01/hoodie-with-logo-2.jpg'),
(902, 41, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:30:\"2019/01/hoodie-with-logo-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(903, 41, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-logo-2.jpg'),
(904, 11, '_wpcom_is_markdown', '1'),
(905, 11, '_wp_old_slug', 'import-placeholder-for-45'),
(906, 11, '_thumbnail_id', '38'),
(907, 12, '_wpcom_is_markdown', '1'),
(908, 12, '_wp_old_slug', 'import-placeholder-for-46'),
(909, 12, '_thumbnail_id', '41'),
(910, 42, '_wp_attached_file', '2019/01/tshirt-2.jpg'),
(911, 42, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2019/01/tshirt-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"tshirt-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"tshirt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"tshirt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(912, 42, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/tshirt-2.jpg'),
(913, 13, '_wpcom_is_markdown', '1'),
(914, 13, '_wp_old_slug', 'import-placeholder-for-47'),
(915, 13, '_thumbnail_id', '42'),
(916, 43, '_wp_attached_file', '2019/01/beanie-2.jpg');
INSERT INTO `mmhs_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(917, 43, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2019/01/beanie-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"beanie-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"beanie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"beanie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(918, 43, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/beanie-2.jpg'),
(919, 14, '_wpcom_is_markdown', '1'),
(920, 14, '_wp_old_slug', 'import-placeholder-for-48'),
(921, 14, '_thumbnail_id', '43'),
(922, 44, '_wp_attached_file', '2019/01/belt-2.jpg'),
(923, 44, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:18:\"2019/01/belt-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"belt-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"belt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"belt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(924, 44, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/belt-2.jpg'),
(925, 15, '_wpcom_is_markdown', '1'),
(926, 15, '_wp_old_slug', 'import-placeholder-for-58'),
(927, 15, '_thumbnail_id', '44'),
(928, 45, '_wp_attached_file', '2019/01/cap-2.jpg'),
(929, 45, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:17:\"2019/01/cap-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"cap-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:17:\"cap-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:17:\"cap-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(930, 45, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/cap-2.jpg'),
(931, 16, '_wpcom_is_markdown', '1'),
(932, 16, '_wp_old_slug', 'import-placeholder-for-60'),
(933, 16, '_thumbnail_id', '83'),
(934, 46, '_wp_attached_file', '2019/01/sunglasses-2.jpg'),
(935, 46, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:24:\"2019/01/sunglasses-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(936, 46, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/sunglasses-2.jpg'),
(937, 17, '_wpcom_is_markdown', '1'),
(938, 17, '_wp_old_slug', 'import-placeholder-for-62'),
(939, 17, '_thumbnail_id', '46'),
(940, 47, '_wp_attached_file', '2019/01/hoodie-with-pocket-2.jpg'),
(941, 47, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:32:\"2019/01/hoodie-with-pocket-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(942, 47, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-pocket-2.jpg'),
(943, 18, '_wpcom_is_markdown', '1'),
(944, 18, '_wp_old_slug', 'import-placeholder-for-64'),
(945, 18, '_thumbnail_id', '47'),
(946, 48, '_wp_attached_file', '2019/01/hoodie-with-zipper-2.jpg'),
(947, 48, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:32:\"2019/01/hoodie-with-zipper-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(948, 48, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-zipper-2.jpg'),
(949, 19, '_wpcom_is_markdown', '1'),
(950, 19, '_wp_old_slug', 'import-placeholder-for-66'),
(951, 19, '_thumbnail_id', '48'),
(952, 49, '_wp_attached_file', '2019/01/long-sleeve-tee-2.jpg'),
(953, 49, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:29:\"2019/01/long-sleeve-tee-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(954, 49, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/long-sleeve-tee-2.jpg'),
(955, 20, '_wpcom_is_markdown', '1'),
(956, 20, '_wp_old_slug', 'import-placeholder-for-68'),
(957, 20, '_thumbnail_id', '49'),
(958, 50, '_wp_attached_file', '2019/01/polo-2.jpg'),
(959, 50, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:801;s:6:\"height\";i:800;s:4:\"file\";s:18:\"2019/01/polo-2.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"polo-2-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"polo-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"polo-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(960, 50, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/polo-2.jpg'),
(961, 21, '_wpcom_is_markdown', '1'),
(962, 21, '_wp_old_slug', 'import-placeholder-for-70'),
(963, 21, '_thumbnail_id', '50'),
(964, 51, '_wp_attached_file', '2019/01/album-1.jpg'),
(965, 51, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:19:\"2019/01/album-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"album-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"album-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"album-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(966, 51, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/album-1.jpg'),
(967, 22, '_wpcom_is_markdown', '1'),
(968, 22, '_wp_old_slug', 'import-placeholder-for-73'),
(969, 22, '_thumbnail_id', '51'),
(970, 52, '_wp_attached_file', '2019/01/single-1.jpg'),
(971, 52, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:20:\"2019/01/single-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"single-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"single-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"single-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(972, 52, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/single-1.jpg'),
(973, 23, '_wpcom_is_markdown', '1'),
(974, 23, '_wp_old_slug', 'import-placeholder-for-75'),
(975, 23, '_thumbnail_id', '52'),
(976, 24, '_wpcom_is_markdown', ''),
(977, 24, '_wp_old_slug', 'import-placeholder-for-76'),
(978, 24, '_variation_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.'),
(979, 24, '_thumbnail_id', '35'),
(980, 24, 'attribute_pa_color', 'red'),
(981, 24, 'attribute_pa_size', ''),
(982, 25, '_wpcom_is_markdown', ''),
(983, 25, '_wp_old_slug', 'import-placeholder-for-77'),
(984, 25, '_variation_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.'),
(985, 25, '_thumbnail_id', '36'),
(986, 25, 'attribute_pa_color', 'green'),
(987, 25, 'attribute_pa_size', ''),
(988, 26, '_wpcom_is_markdown', ''),
(989, 26, '_wp_old_slug', 'import-placeholder-for-78'),
(990, 26, '_variation_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.'),
(991, 26, '_thumbnail_id', '37'),
(992, 26, 'attribute_pa_color', 'blue'),
(993, 26, 'attribute_pa_size', ''),
(994, 27, '_wpcom_is_markdown', ''),
(995, 27, '_wp_old_slug', 'import-placeholder-for-79'),
(996, 27, '_variation_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.'),
(997, 27, '_thumbnail_id', '38'),
(998, 27, 'attribute_pa_color', 'red'),
(999, 27, 'attribute_logo', 'No'),
(1000, 28, '_wpcom_is_markdown', ''),
(1001, 28, '_wp_old_slug', 'import-placeholder-for-80'),
(1002, 28, '_variation_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.'),
(1003, 28, '_thumbnail_id', '40'),
(1004, 28, 'attribute_pa_color', 'green'),
(1005, 28, 'attribute_logo', 'No'),
(1006, 29, '_wpcom_is_markdown', ''),
(1007, 29, '_wp_old_slug', 'import-placeholder-for-81'),
(1008, 29, '_variation_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.'),
(1009, 29, '_thumbnail_id', '39'),
(1010, 29, 'attribute_pa_color', 'blue'),
(1011, 29, 'attribute_logo', 'No'),
(1012, 53, '_wp_attached_file', '2019/01/t-shirt-with-logo-1.jpg'),
(1013, 53, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:31:\"2019/01/t-shirt-with-logo-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1014, 53, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/t-shirt-with-logo-1.jpg'),
(1015, 30, '_wpcom_is_markdown', '1'),
(1016, 30, '_wp_old_slug', 'import-placeholder-for-83'),
(1017, 30, '_thumbnail_id', '53'),
(1018, 54, '_wp_attached_file', '2019/01/beanie-with-logo-1.jpg'),
(1019, 54, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:30:\"2019/01/beanie-with-logo-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1020, 54, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/beanie-with-logo-1.jpg'),
(1021, 31, '_wpcom_is_markdown', '1'),
(1022, 31, '_wp_old_slug', 'import-placeholder-for-85'),
(1023, 31, '_thumbnail_id', '54'),
(1024, 10, '_price', '15'),
(1025, 10, '_price', '20'),
(1026, 10, '_regular_price', ''),
(1027, 10, '_sale_price', ''),
(1032, 55, '_wp_attached_file', '2019/01/logo-1.jpg'),
(1033, 55, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:799;s:4:\"file\";s:18:\"2019/01/logo-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"logo-1-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"logo-1-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"logo-1-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1034, 55, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/logo-1.jpg'),
(1035, 32, '_wpcom_is_markdown', '1'),
(1036, 32, '_wp_old_slug', 'import-placeholder-for-87'),
(1037, 32, '_children', 'a:3:{i:0;i:12;i:1;i:13;i:2;i:14;}'),
(1038, 32, '_thumbnail_id', '55'),
(1039, 32, '_price', '18'),
(1040, 32, '_price', '45'),
(1041, 56, '_wp_attached_file', '2019/01/pennant-1.jpg'),
(1042, 56, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:21:\"2019/01/pennant-1.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"pennant-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:21:\"pennant-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:21:\"pennant-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1043, 56, '_wc_attachment_source', 'https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/pennant-1.jpg'),
(1044, 33, '_wpcom_is_markdown', '1'),
(1045, 33, '_wp_old_slug', 'import-placeholder-for-89'),
(1046, 33, '_thumbnail_id', '56'),
(1047, 33, '_product_url', 'https://mercantile.wordpress.org/product/wordpress-pennant/'),
(1048, 33, '_button_text', 'Buy From WordPress store!'),
(1049, 34, '_wpcom_is_markdown', ''),
(1050, 34, '_wp_old_slug', 'import-placeholder-for-90'),
(1051, 34, '_variation_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.'),
(1052, 34, '_thumbnail_id', '41'),
(1053, 34, 'attribute_pa_color', 'blue'),
(1054, 34, 'attribute_logo', 'Yes'),
(1059, 5, '_edit_lock', '1548489965:1'),
(1060, 59, '_menu_item_type', 'post_type'),
(1061, 59, '_menu_item_menu_item_parent', '0'),
(1062, 59, '_menu_item_object_id', '8'),
(1063, 59, '_menu_item_object', 'page'),
(1064, 59, '_menu_item_target', ''),
(1065, 59, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1066, 59, '_menu_item_xfn', ''),
(1067, 59, '_menu_item_url', ''),
(1069, 60, '_menu_item_type', 'post_type'),
(1070, 60, '_menu_item_menu_item_parent', '0'),
(1071, 60, '_menu_item_object_id', '7'),
(1072, 60, '_menu_item_object', 'page'),
(1073, 60, '_menu_item_target', ''),
(1074, 60, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1075, 60, '_menu_item_xfn', ''),
(1076, 60, '_menu_item_url', ''),
(1078, 61, '_menu_item_type', 'post_type'),
(1079, 61, '_menu_item_menu_item_parent', '0'),
(1080, 61, '_menu_item_object_id', '6'),
(1081, 61, '_menu_item_object', 'page'),
(1082, 61, '_menu_item_target', ''),
(1083, 61, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1084, 61, '_menu_item_xfn', ''),
(1085, 61, '_menu_item_url', ''),
(1087, 62, '_menu_item_type', 'post_type'),
(1088, 62, '_menu_item_menu_item_parent', '0'),
(1089, 62, '_menu_item_object_id', '5'),
(1090, 62, '_menu_item_object', 'page'),
(1091, 62, '_menu_item_target', ''),
(1092, 62, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1093, 62, '_menu_item_xfn', ''),
(1094, 62, '_menu_item_url', ''),
(1105, 64, '_edit_lock', '1548230351:1'),
(1106, 64, '_wp_page_template', 'page-custom_home_page.php'),
(1117, 71, '_menu_item_type', 'post_type'),
(1118, 71, '_menu_item_menu_item_parent', '0'),
(1119, 71, '_menu_item_object_id', '64'),
(1120, 71, '_menu_item_object', 'page'),
(1121, 71, '_menu_item_target', ''),
(1122, 71, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(1123, 71, '_menu_item_xfn', ''),
(1124, 71, '_menu_item_url', ''),
(1126, 71, '_megamenu', 'a:2:{s:4:\"type\";s:4:\"grid\";s:4:\"grid\";a:1:{i:0;a:2:{s:4:\"meta\";a:4:{s:5:\"class\";s:0:\"\";s:15:\"hide-on-desktop\";s:5:\"false\";s:14:\"hide-on-mobile\";s:5:\"false\";s:7:\"columns\";s:2:\"12\";}s:7:\"columns\";a:3:{i:0;a:2:{s:4:\"meta\";a:4:{s:4:\"span\";s:1:\"4\";s:5:\"class\";s:0:\"\";s:15:\"hide-on-desktop\";s:5:\"false\";s:14:\"hide-on-mobile\";s:5:\"false\";}s:5:\"items\";a:1:{i:0;a:2:{s:2:\"id\";s:13:\"media_image-2\";s:4:\"type\";s:6:\"widget\";}}}i:1;a:2:{s:4:\"meta\";a:4:{s:4:\"span\";s:1:\"4\";s:5:\"class\";s:0:\"\";s:15:\"hide-on-desktop\";s:5:\"false\";s:14:\"hide-on-mobile\";s:5:\"false\";}s:5:\"items\";a:1:{i:0;a:2:{s:2:\"id\";s:13:\"media_image-3\";s:4:\"type\";s:6:\"widget\";}}}i:2;a:2:{s:4:\"meta\";a:4:{s:4:\"span\";s:1:\"4\";s:5:\"class\";s:0:\"\";s:15:\"hide-on-desktop\";s:5:\"false\";s:14:\"hide-on-mobile\";s:5:\"false\";}s:5:\"items\";a:1:{i:0;a:2:{s:2:\"id\";s:13:\"media_image-4\";s:4:\"type\";s:6:\"widget\";}}}}}}}'),
(1127, 72, '_wp_attached_file', '2019/01/Keys-Case.png'),
(1128, 72, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:21:\"2019/01/Keys-Case.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"Keys-Case-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"Keys-Case-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1129, 73, '_wp_attached_file', '2019/01/Laptop-Bag.png'),
(1130, 73, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:22:\"2019/01/Laptop-Bag.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:21:\"Laptop-Bag-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:21:\"Laptop-Bag-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1131, 74, '_wp_attached_file', '2019/01/Mens-leather-bag.png'),
(1132, 74, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:28:\"2019/01/Mens-leather-bag.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:27:\"Mens-leather-bag-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:27:\"Mens-leather-bag-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1133, 75, '_wp_attached_file', '2019/01/Mens-wallets.png'),
(1134, 75, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:24:\"2019/01/Mens-wallets.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:23:\"Mens-wallets-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:23:\"Mens-wallets-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1135, 76, '_wp_attached_file', '2019/01/Pouches.png'),
(1136, 76, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:19:\"2019/01/Pouches.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"Pouches-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"Pouches-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1137, 77, '_wp_attached_file', '2019/01/Pouches2.png'),
(1138, 77, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:20:\"2019/01/Pouches2.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"Pouches2-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"Pouches2-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1139, 78, '_wp_attached_file', '2019/01/PU-Leather-Bag.png'),
(1140, 78, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:26:\"2019/01/PU-Leather-Bag.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"PU-Leather-Bag-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"PU-Leather-Bag-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1141, 79, '_wp_attached_file', '2019/01/Travel-wallets.png'),
(1142, 79, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:26:\"2019/01/Travel-wallets.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"Travel-wallets-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"Travel-wallets-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1143, 80, '_wp_attached_file', '2019/01/Womens-leather-bag.png'),
(1144, 80, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:30:\"2019/01/Womens-leather-bag.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"Womens-leather-bag-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"Womens-leather-bag-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1145, 81, '_wp_attached_file', '2019/01/Womens-wallets.png'),
(1146, 81, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:100;s:6:\"height\";i:70;s:4:\"file\";s:26:\"2019/01/Womens-wallets.png\";s:5:\"sizes\";a:2:{s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"Womens-wallets-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"Womens-wallets-100x70.png\";s:5:\"width\";i:100;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1147, 16, '_edit_lock', '1548162494:1'),
(1148, 16, '_edit_last', '1'),
(1149, 83, '_wp_attached_file', '2019/01/Products-One.jpg');
INSERT INTO `mmhs_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1150, 83, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:24:\"2019/01/Products-One.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"Products-One-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"Products-One-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"Products-One-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"Products-One-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:24:\"Products-One-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"Products-One-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:24:\"Products-One-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:24:\"Products-One-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"Products-One-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1151, 7, '_edit_lock', '1548498304:1'),
(1152, 11, '_edit_lock', '1548313523:1'),
(1157, 11, '_price', '42'),
(1158, 11, '_price', '45'),
(1159, 11, '_regular_price', ''),
(1160, 11, '_sale_price', ''),
(1161, 33, '_edit_lock', '1548325325:1'),
(1162, 33, '_edit_last', '1'),
(1163, 7, '_wp_page_template', 'page-custom_checkout.php'),
(1164, 99, '_order_key', 'wc_order_ksWUz3ODhWGiS'),
(1165, 99, '_customer_user', '1'),
(1166, 99, '_payment_method', 'cheque'),
(1167, 99, '_payment_method_title', 'Check payments'),
(1168, 99, '_transaction_id', ''),
(1169, 99, '_customer_ip_address', '127.0.0.1'),
(1170, 99, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0'),
(1171, 99, '_created_via', 'checkout'),
(1172, 99, '_date_completed', ''),
(1173, 99, '_completed_date', ''),
(1174, 99, '_date_paid', ''),
(1175, 99, '_paid_date', ''),
(1176, 99, '_cart_hash', '4ca7da16573f2e56130a2e1d496b8c97'),
(1177, 99, '_billing_first_name', 'Md. Mehedi Hassan'),
(1178, 99, '_billing_last_name', 'Sharif'),
(1179, 99, '_billing_company', ''),
(1180, 99, '_billing_address_1', 'House No - 43, Road No -10'),
(1181, 99, '_billing_address_2', ''),
(1182, 99, '_billing_city', 'Dhaka'),
(1183, 99, '_billing_state', 'BD-13'),
(1184, 99, '_billing_postcode', '2800'),
(1185, 99, '_billing_country', 'BD'),
(1186, 99, '_billing_email', 'mehedi00014@gmail.com'),
(1187, 99, '_billing_phone', '+8801728443313'),
(1188, 99, '_shipping_first_name', 'Md. Mehedi Hassan'),
(1189, 99, '_shipping_last_name', 'Sharif'),
(1190, 99, '_shipping_company', ''),
(1191, 99, '_shipping_address_1', 'House No - 43, Road No -10'),
(1192, 99, '_shipping_address_2', ''),
(1193, 99, '_shipping_city', 'Dhaka'),
(1194, 99, '_shipping_state', 'BD-13'),
(1195, 99, '_shipping_postcode', '2800'),
(1196, 99, '_shipping_country', 'BD'),
(1197, 99, '_order_currency', 'BDT'),
(1198, 99, '_cart_discount', '0'),
(1199, 99, '_cart_discount_tax', '0'),
(1200, 99, '_order_shipping', '0.00'),
(1201, 99, '_order_shipping_tax', '0'),
(1202, 99, '_order_tax', '0'),
(1203, 99, '_order_total', '1062.00'),
(1204, 99, '_order_version', '3.5.4'),
(1205, 99, '_prices_include_tax', 'no'),
(1206, 99, '_billing_address_index', 'Md. Mehedi Hassan Sharif  House No - 43, Road No -10  Dhaka BD-13 2800 BD mehedi00014@gmail.com +8801728443313'),
(1207, 99, '_shipping_address_index', 'Md. Mehedi Hassan Sharif  House No - 43, Road No -10  Dhaka BD-13 2800 BD'),
(1208, 99, '_recorded_sales', 'yes'),
(1209, 99, '_recorded_coupon_usage_counts', 'yes'),
(1210, 99, '_order_stock_reduced', 'yes'),
(1214, 6, '_edit_lock', '1548562480:1'),
(1215, 6, '_wp_page_template', 'page-custom_cart.php'),
(1216, 102, '_order_key', 'wc_order_F8CEnIqldLC7C'),
(1217, 102, '_customer_user', '1'),
(1218, 102, '_payment_method', 'bacs'),
(1219, 102, '_payment_method_title', 'Direct bank transfer'),
(1220, 102, '_transaction_id', ''),
(1221, 102, '_customer_ip_address', '::1'),
(1222, 102, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0'),
(1223, 102, '_created_via', 'checkout'),
(1224, 102, '_date_completed', ''),
(1225, 102, '_completed_date', ''),
(1226, 102, '_date_paid', ''),
(1227, 102, '_paid_date', ''),
(1228, 102, '_cart_hash', 'c712881b00b7b33c7c4d3422a2785e72'),
(1229, 102, '_billing_first_name', 'Md. Mehedi Hassan'),
(1230, 102, '_billing_last_name', 'Sharif'),
(1231, 102, '_billing_company', ''),
(1232, 102, '_billing_address_1', 'House No - 43, Road No -10'),
(1233, 102, '_billing_address_2', ''),
(1234, 102, '_billing_city', 'Dhaka'),
(1235, 102, '_billing_state', 'BD-13'),
(1236, 102, '_billing_postcode', '2800'),
(1237, 102, '_billing_country', 'BD'),
(1238, 102, '_billing_email', 'mehedi00014@gmail.com'),
(1239, 102, '_billing_phone', '+8801728443313'),
(1240, 102, '_shipping_first_name', 'Md. Mehedi Hassan'),
(1241, 102, '_shipping_last_name', 'Sharif'),
(1242, 102, '_shipping_company', ''),
(1243, 102, '_shipping_address_1', 'House No - 43, Road No -10'),
(1244, 102, '_shipping_address_2', ''),
(1245, 102, '_shipping_city', 'Dhaka'),
(1246, 102, '_shipping_state', 'BD-13'),
(1247, 102, '_shipping_postcode', '2800'),
(1248, 102, '_shipping_country', 'BD'),
(1249, 102, '_order_currency', 'BDT'),
(1250, 102, '_cart_discount', '0'),
(1251, 102, '_cart_discount_tax', '0'),
(1252, 102, '_order_shipping', '0.00'),
(1253, 102, '_order_shipping_tax', '0'),
(1254, 102, '_order_tax', '0'),
(1255, 102, '_order_total', '176.00'),
(1256, 102, '_order_version', '3.5.4'),
(1257, 102, '_prices_include_tax', 'no'),
(1258, 102, '_billing_address_index', 'Md. Mehedi Hassan Sharif  House No - 43, Road No -10  Dhaka BD-13 2800 BD mehedi00014@gmail.com +8801728443313'),
(1259, 102, '_shipping_address_index', 'Md. Mehedi Hassan Sharif  House No - 43, Road No -10  Dhaka BD-13 2800 BD'),
(1260, 102, '_recorded_sales', 'yes'),
(1261, 102, '_recorded_coupon_usage_counts', 'yes'),
(1262, 102, '_order_stock_reduced', 'yes'),
(1263, 103, '_order_key', 'wc_order_ghh4nZ3noaRWY'),
(1264, 103, '_customer_user', '1'),
(1265, 103, '_payment_method', 'bacs'),
(1266, 103, '_payment_method_title', 'Direct bank transfer'),
(1267, 103, '_transaction_id', ''),
(1268, 103, '_customer_ip_address', '::1'),
(1269, 103, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0'),
(1270, 103, '_created_via', 'checkout'),
(1271, 103, '_date_completed', ''),
(1272, 103, '_completed_date', ''),
(1273, 103, '_date_paid', ''),
(1274, 103, '_paid_date', ''),
(1275, 103, '_cart_hash', '580872f312e8df98888e88a734775e0f'),
(1276, 103, '_billing_first_name', 'Md. Mehedi Hassan'),
(1277, 103, '_billing_last_name', 'Sharif'),
(1278, 103, '_billing_company', ''),
(1279, 103, '_billing_address_1', 'House No - 43, Road No -10'),
(1280, 103, '_billing_address_2', ''),
(1281, 103, '_billing_city', 'Dhaka'),
(1282, 103, '_billing_state', 'BD-13'),
(1283, 103, '_billing_postcode', '2800'),
(1284, 103, '_billing_country', 'BD'),
(1285, 103, '_billing_email', 'mehedi00014@gmail.com'),
(1286, 103, '_billing_phone', '+8801728443313'),
(1287, 103, '_shipping_first_name', ''),
(1288, 103, '_shipping_last_name', ''),
(1289, 103, '_shipping_company', ''),
(1290, 103, '_shipping_address_1', ''),
(1291, 103, '_shipping_address_2', ''),
(1292, 103, '_shipping_city', ''),
(1293, 103, '_shipping_state', ''),
(1294, 103, '_shipping_postcode', ''),
(1295, 103, '_shipping_country', ''),
(1296, 103, '_order_currency', 'BDT'),
(1297, 103, '_cart_discount', '0'),
(1298, 103, '_cart_discount_tax', '0'),
(1299, 103, '_order_shipping', '0.00'),
(1300, 103, '_order_shipping_tax', '0'),
(1301, 103, '_order_tax', '0'),
(1302, 103, '_order_total', '90.00'),
(1303, 103, '_order_version', '3.5.4'),
(1304, 103, '_prices_include_tax', 'no'),
(1305, 103, '_billing_address_index', 'Md. Mehedi Hassan Sharif  House No - 43, Road No -10  Dhaka BD-13 2800 BD mehedi00014@gmail.com +8801728443313'),
(1306, 103, '_shipping_address_index', '        '),
(1307, 103, '_recorded_sales', 'yes'),
(1308, 103, '_recorded_coupon_usage_counts', 'yes'),
(1309, 103, '_order_stock_reduced', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_posts`
--

CREATE TABLE `mmhs_wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_posts`
--

INSERT INTO `mmhs_wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-01-15 11:17:47', '2019-01-15 11:17:47', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2019-01-15 11:17:47', '2019-01-15 11:17:47', '', 0, 'http://localhost/gctl/?p=1', 0, 'post', '', 1),
(3, 1, '2019-01-15 11:17:47', '2019-01-15 11:17:47', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost/gctl.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2019-01-15 11:17:47', '2019-01-15 11:17:47', '', 0, 'http://localhost/gctl/?page_id=3', 0, 'page', '', 0),
(5, 1, '2019-01-15 11:28:52', '2019-01-15 11:28:52', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2019-01-17 14:47:55', '2019-01-17 14:47:55', '', 0, 'http://localhost/gctl/shop/', 0, 'page', '', 0),
(6, 1, '2019-01-15 11:28:53', '2019-01-15 11:28:53', '[woocommerce_cart]', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2019-01-27 04:16:34', '2019-01-27 04:16:34', '', 0, 'http://localhost/gctl/cart/', 0, 'page', '', 0),
(7, 1, '2019-01-15 11:28:53', '2019-01-15 11:28:53', '<p>[woocommerce_checkout]</p>\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2019-01-26 09:48:23', '2019-01-26 09:48:23', '', 0, 'http://localhost/gctl/checkout/', 0, 'page', '', 0),
(8, 1, '2019-01-15 11:28:53', '2019-01-15 11:28:53', '[woocommerce_my_account]', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2019-01-15 11:28:53', '2019-01-15 11:28:53', '', 0, 'http://localhost/gctl/my-account/', 0, 'page', '', 0),
(10, 1, '2019-01-15 11:34:07', '2019-01-15 11:34:07', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'V-Neck T-Shirt', 'This is a variable product.', 'publish', 'open', 'closed', '', 'v-neck-t-shirt', '', '', '2019-01-15 11:37:20', '2019-01-15 11:37:20', '', 0, 'http://localhost/gctl/product/import-placeholder-for-44/', 0, 'product', '', 0),
(11, 1, '2019-01-15 11:34:10', '2019-01-15 11:34:10', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Hoodie', 'This is a variable product.', 'publish', 'open', 'closed', '', 'hoodie', '', '', '2019-01-24 06:14:54', '2019-01-24 06:14:54', '', 0, 'http://localhost/gctl/product/import-placeholder-for-45/', 0, 'product', '', 0),
(12, 1, '2019-01-15 11:34:13', '2019-01-15 11:34:13', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Hoodie with Logo', 'This is a simple product.', 'publish', 'open', 'closed', '', 'hoodie-with-logo', '', '', '2019-01-15 11:35:45', '2019-01-15 11:35:45', '', 0, 'http://localhost/gctl/product/import-placeholder-for-46/', 0, 'product', '', 0),
(13, 1, '2019-01-15 11:34:16', '2019-01-15 11:34:16', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'T-Shirt', 'This is a simple product.', 'publish', 'open', 'closed', '', 't-shirt', '', '', '2019-01-15 11:35:53', '2019-01-15 11:35:53', '', 0, 'http://localhost/gctl/product/import-placeholder-for-47/', 0, 'product', '', 0),
(14, 1, '2019-01-15 11:34:18', '2019-01-15 11:34:18', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Beanie', 'This is a simple product.', 'publish', 'open', 'closed', '', 'beanie', '', '', '2019-01-15 11:35:58', '2019-01-15 11:35:58', '', 0, 'http://localhost/gctl/product/import-placeholder-for-48/', 0, 'product', '', 0),
(15, 1, '2019-01-15 11:34:21', '2019-01-15 11:34:21', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Belt', 'This is a simple product.', 'publish', 'open', 'closed', '', 'belt', '', '', '2019-01-15 11:36:03', '2019-01-15 11:36:03', '', 0, 'http://localhost/gctl/product/import-placeholder-for-58/', 0, 'product', '', 0),
(16, 1, '2019-01-15 11:34:22', '2019-01-15 11:34:22', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Cap', 'This is a simple product.', 'publish', 'open', 'closed', '', 'cap', '', '', '2019-01-22 10:34:32', '2019-01-22 10:34:32', '', 0, 'http://localhost/gctl/product/import-placeholder-for-60/', 0, 'product', '', 0),
(17, 1, '2019-01-15 11:34:24', '2019-01-15 11:34:24', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Sunglasses', 'This is a simple product.', 'publish', 'open', 'closed', '', 'sunglasses', '', '', '2019-01-15 11:36:16', '2019-01-15 11:36:16', '', 0, 'http://localhost/gctl/product/import-placeholder-for-62/', 0, 'product', '', 0),
(18, 1, '2019-01-15 11:34:27', '2019-01-15 11:34:27', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Hoodie with Pocket', 'This is a simple product.', 'publish', 'open', 'closed', '', 'hoodie-with-pocket', '', '', '2019-01-15 11:36:21', '2019-01-15 11:36:21', '', 0, 'http://localhost/gctl/product/import-placeholder-for-64/', 0, 'product', '', 0),
(19, 1, '2019-01-15 11:34:30', '2019-01-15 11:34:30', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Hoodie with Zipper', 'This is a simple product.', 'publish', 'open', 'closed', '', 'hoodie-with-zipper', '', '', '2019-01-15 11:36:28', '2019-01-15 11:36:28', '', 0, 'http://localhost/gctl/product/import-placeholder-for-66/', 0, 'product', '', 0),
(20, 1, '2019-01-15 11:34:33', '2019-01-15 11:34:33', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Long Sleeve Tee', 'This is a simple product.', 'publish', 'open', 'closed', '', 'long-sleeve-tee', '', '', '2019-01-15 11:36:35', '2019-01-15 11:36:35', '', 0, 'http://localhost/gctl/product/import-placeholder-for-68/', 0, 'product', '', 0),
(21, 1, '2019-01-15 11:34:35', '2019-01-15 11:34:35', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Polo', 'This is a simple product.', 'publish', 'open', 'closed', '', 'polo', '', '', '2019-01-15 11:36:42', '2019-01-15 11:36:42', '', 0, 'http://localhost/gctl/product/import-placeholder-for-70/', 0, 'product', '', 0),
(22, 1, '2019-01-15 11:34:37', '2019-01-15 11:34:37', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.', 'Album', 'This is a simple, virtual product.', 'publish', 'open', 'closed', '', 'album', '', '', '2019-01-15 11:36:48', '2019-01-15 11:36:48', '', 0, 'http://localhost/gctl/product/import-placeholder-for-73/', 0, 'product', '', 0),
(23, 1, '2019-01-15 11:34:39', '2019-01-15 11:34:39', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.', 'Single', 'This is a simple, virtual product.', 'publish', 'open', 'closed', '', 'single', '', '', '2019-01-15 11:36:56', '2019-01-15 11:36:56', '', 0, 'http://localhost/gctl/product/import-placeholder-for-75/', 0, 'product', '', 0),
(24, 1, '2019-01-15 11:34:40', '2019-01-15 11:34:40', '', 'V-Neck T-Shirt - Red', '', 'publish', 'closed', 'closed', '', 'v-neck-t-shirt-red', '', '', '2019-01-15 11:37:01', '2019-01-15 11:37:01', '', 10, 'http://localhost/gctl/product/import-placeholder-for-76/', 0, 'product_variation', '', 0),
(25, 1, '2019-01-15 11:34:44', '2019-01-15 11:34:44', '', 'V-Neck T-Shirt - Green', '', 'publish', 'closed', 'closed', '', 'v-neck-t-shirt-green', '', '', '2019-01-15 11:37:04', '2019-01-15 11:37:04', '', 10, 'http://localhost/gctl/product/import-placeholder-for-77/', 0, 'product_variation', '', 0),
(26, 1, '2019-01-15 11:34:47', '2019-01-15 11:34:47', '', 'V-Neck T-Shirt - Blue', '', 'publish', 'closed', 'closed', '', 'v-neck-t-shirt-blue', '', '', '2019-01-15 11:37:04', '2019-01-15 11:37:04', '', 10, 'http://localhost/gctl/product/import-placeholder-for-78/', 0, 'product_variation', '', 0),
(27, 1, '2019-01-15 11:34:50', '2019-01-15 11:34:50', '', 'Hoodie - Red, No', '', 'publish', 'closed', 'closed', '', 'hoodie-red-no', '', '', '2019-01-24 06:14:53', '2019-01-24 06:14:53', '', 11, 'http://localhost/gctl/product/import-placeholder-for-79/', 1, 'product_variation', '', 0),
(28, 1, '2019-01-15 11:34:51', '2019-01-15 11:34:51', '', 'Hoodie - Green, No', '', 'publish', 'closed', 'closed', '', 'hoodie-green-no', '', '', '2019-01-15 11:37:07', '2019-01-15 11:37:07', '', 11, 'http://localhost/gctl/product/import-placeholder-for-80/', 3, 'product_variation', '', 0),
(29, 1, '2019-01-15 11:34:53', '2019-01-15 11:34:53', '', 'Hoodie - Blue, No', '', 'publish', 'closed', 'closed', '', 'hoodie-blue-no', '', '', '2019-01-15 11:37:08', '2019-01-15 11:37:08', '', 11, 'http://localhost/gctl/product/import-placeholder-for-81/', 4, 'product_variation', '', 0),
(30, 1, '2019-01-15 11:34:55', '2019-01-15 11:34:55', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'T-Shirt with Logo', 'This is a simple product.', 'publish', 'open', 'closed', '', 't-shirt-with-logo', '', '', '2019-01-15 11:37:13', '2019-01-15 11:37:13', '', 0, 'http://localhost/gctl/product/import-placeholder-for-83/', 0, 'product', '', 0),
(31, 1, '2019-01-15 11:34:56', '2019-01-15 11:34:56', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Beanie with Logo', 'This is a simple product.', 'publish', 'open', 'closed', '', 'beanie-with-logo', '', '', '2019-01-15 11:37:18', '2019-01-15 11:37:18', '', 0, 'http://localhost/gctl/product/import-placeholder-for-85/', 0, 'product', '', 0),
(32, 1, '2019-01-15 11:34:59', '2019-01-15 11:34:59', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Logo Collection', 'This is a grouped product.', 'publish', 'open', 'closed', '', 'logo-collection', '', '', '2019-01-15 11:37:27', '2019-01-15 11:37:27', '', 0, 'http://localhost/gctl/product/import-placeholder-for-87/', 0, 'product', '', 0),
(33, 1, '2019-01-15 11:35:01', '2019-01-15 11:35:01', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'WordPress Pennant', 'This is an external product.', 'publish', 'open', 'closed', '', 'wordpress-pennant', '', '', '2019-01-24 07:09:23', '2019-01-24 07:09:23', '', 0, 'http://localhost/gctl/product/import-placeholder-for-89/', 0, 'product', '', 0),
(34, 1, '2019-01-15 11:35:03', '2019-01-15 11:35:03', '', 'Hoodie - Blue, Yes', '', 'publish', 'closed', 'closed', '', 'hoodie-blue-yes', '', '', '2019-01-15 11:37:33', '2019-01-15 11:37:33', '', 11, 'http://localhost/gctl/product/import-placeholder-for-90/', 2, 'product_variation', '', 0),
(35, 1, '2019-01-15 11:35:10', '2019-01-15 11:35:10', '', 'vneck-tee-2.jpg', '', 'inherit', 'open', 'closed', '', 'vneck-tee-2-jpg', '', '', '2019-01-15 11:35:10', '2019-01-15 11:35:10', '', 10, 'http://localhost/gctl/wp-content/uploads/2019/01/vneck-tee-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(36, 1, '2019-01-15 11:35:14', '2019-01-15 11:35:14', '', 'vnech-tee-green-1.jpg', '', 'inherit', 'open', 'closed', '', 'vnech-tee-green-1-jpg', '', '', '2019-01-15 11:35:14', '2019-01-15 11:35:14', '', 10, 'http://localhost/gctl/wp-content/uploads/2019/01/vnech-tee-green-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2019-01-15 11:35:19', '2019-01-15 11:35:19', '', 'vnech-tee-blue-1.jpg', '', 'inherit', 'open', 'closed', '', 'vnech-tee-blue-1-jpg', '', '', '2019-01-15 11:35:19', '2019-01-15 11:35:19', '', 10, 'http://localhost/gctl/wp-content/uploads/2019/01/vnech-tee-blue-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(38, 1, '2019-01-15 11:35:27', '2019-01-15 11:35:27', '', 'hoodie-2.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-2-jpg', '', '', '2019-01-15 11:35:27', '2019-01-15 11:35:27', '', 11, 'http://localhost/gctl/wp-content/uploads/2019/01/hoodie-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(39, 1, '2019-01-15 11:35:30', '2019-01-15 11:35:30', '', 'hoodie-blue-1.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-blue-1-jpg', '', '', '2019-01-15 11:35:30', '2019-01-15 11:35:30', '', 11, 'http://localhost/gctl/wp-content/uploads/2019/01/hoodie-blue-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(40, 1, '2019-01-15 11:35:34', '2019-01-15 11:35:34', '', 'hoodie-green-1.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-green-1-jpg', '', '', '2019-01-15 11:35:34', '2019-01-15 11:35:34', '', 11, 'http://localhost/gctl/wp-content/uploads/2019/01/hoodie-green-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2019-01-15 11:35:38', '2019-01-15 11:35:38', '', 'hoodie-with-logo-2.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-with-logo-2-jpg', '', '', '2019-01-15 11:35:38', '2019-01-15 11:35:38', '', 11, 'http://localhost/gctl/wp-content/uploads/2019/01/hoodie-with-logo-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2019-01-15 11:35:50', '2019-01-15 11:35:50', '', 'tshirt-2.jpg', '', 'inherit', 'open', 'closed', '', 'tshirt-2-jpg', '', '', '2019-01-15 11:35:50', '2019-01-15 11:35:50', '', 13, 'http://localhost/gctl/wp-content/uploads/2019/01/tshirt-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2019-01-15 11:35:56', '2019-01-15 11:35:56', '', 'beanie-2.jpg', '', 'inherit', 'open', 'closed', '', 'beanie-2-jpg', '', '', '2019-01-15 11:35:56', '2019-01-15 11:35:56', '', 14, 'http://localhost/gctl/wp-content/uploads/2019/01/beanie-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2019-01-15 11:36:02', '2019-01-15 11:36:02', '', 'belt-2.jpg', '', 'inherit', 'open', 'closed', '', 'belt-2-jpg', '', '', '2019-01-15 11:36:02', '2019-01-15 11:36:02', '', 15, 'http://localhost/gctl/wp-content/uploads/2019/01/belt-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2019-01-15 11:36:09', '2019-01-15 11:36:09', '', 'cap-2.jpg', '', 'inherit', 'open', 'closed', '', 'cap-2-jpg', '', '', '2019-01-15 11:36:09', '2019-01-15 11:36:09', '', 16, 'http://localhost/gctl/wp-content/uploads/2019/01/cap-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2019-01-15 11:36:14', '2019-01-15 11:36:14', '', 'sunglasses-2.jpg', '', 'inherit', 'open', 'closed', '', 'sunglasses-2-jpg', '', '', '2019-01-15 11:36:14', '2019-01-15 11:36:14', '', 17, 'http://localhost/gctl/wp-content/uploads/2019/01/sunglasses-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(47, 1, '2019-01-15 11:36:19', '2019-01-15 11:36:19', '', 'hoodie-with-pocket-2.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-with-pocket-2-jpg', '', '', '2019-01-15 11:36:19', '2019-01-15 11:36:19', '', 18, 'http://localhost/gctl/wp-content/uploads/2019/01/hoodie-with-pocket-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2019-01-15 11:36:26', '2019-01-15 11:36:26', '', 'hoodie-with-zipper-2.jpg', '', 'inherit', 'open', 'closed', '', 'hoodie-with-zipper-2-jpg', '', '', '2019-01-15 11:36:26', '2019-01-15 11:36:26', '', 19, 'http://localhost/gctl/wp-content/uploads/2019/01/hoodie-with-zipper-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2019-01-15 11:36:33', '2019-01-15 11:36:33', '', 'long-sleeve-tee-2.jpg', '', 'inherit', 'open', 'closed', '', 'long-sleeve-tee-2-jpg', '', '', '2019-01-15 11:36:33', '2019-01-15 11:36:33', '', 20, 'http://localhost/gctl/wp-content/uploads/2019/01/long-sleeve-tee-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2019-01-15 11:36:40', '2019-01-15 11:36:40', '', 'polo-2.jpg', '', 'inherit', 'open', 'closed', '', 'polo-2-jpg', '', '', '2019-01-15 11:36:40', '2019-01-15 11:36:40', '', 21, 'http://localhost/gctl/wp-content/uploads/2019/01/polo-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2019-01-15 11:36:47', '2019-01-15 11:36:47', '', 'album-1.jpg', '', 'inherit', 'open', 'closed', '', 'album-1-jpg', '', '', '2019-01-15 11:36:47', '2019-01-15 11:36:47', '', 22, 'http://localhost/gctl/wp-content/uploads/2019/01/album-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2019-01-15 11:36:54', '2019-01-15 11:36:54', '', 'single-1.jpg', '', 'inherit', 'open', 'closed', '', 'single-1-jpg', '', '', '2019-01-15 11:36:54', '2019-01-15 11:36:54', '', 23, 'http://localhost/gctl/wp-content/uploads/2019/01/single-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2019-01-15 11:37:11', '2019-01-15 11:37:11', '', 't-shirt-with-logo-1.jpg', '', 'inherit', 'open', 'closed', '', 't-shirt-with-logo-1-jpg', '', '', '2019-01-15 11:37:11', '2019-01-15 11:37:11', '', 30, 'http://localhost/gctl/wp-content/uploads/2019/01/t-shirt-with-logo-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2019-01-15 11:37:17', '2019-01-15 11:37:17', '', 'beanie-with-logo-1.jpg', '', 'inherit', 'open', 'closed', '', 'beanie-with-logo-1-jpg', '', '', '2019-01-15 11:37:17', '2019-01-15 11:37:17', '', 31, 'http://localhost/gctl/wp-content/uploads/2019/01/beanie-with-logo-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2019-01-15 11:37:26', '2019-01-15 11:37:26', '', 'logo-1.jpg', '', 'inherit', 'open', 'closed', '', 'logo-1-jpg', '', '', '2019-01-15 11:37:26', '2019-01-15 11:37:26', '', 32, 'http://localhost/gctl/wp-content/uploads/2019/01/logo-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2019-01-15 11:37:31', '2019-01-15 11:37:31', '', 'pennant-1.jpg', '', 'inherit', 'open', 'closed', '', 'pennant-1-jpg', '', '', '2019-01-15 11:37:31', '2019-01-15 11:37:31', '', 33, 'http://localhost/gctl/wp-content/uploads/2019/01/pennant-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2019-01-17 14:47:55', '2019-01-17 14:47:55', '', 'Shop', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2019-01-17 14:47:55', '2019-01-17 14:47:55', '', 5, 'http://localhost/gctl/2019/01/17/5-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2019-01-19 05:29:19', '2019-01-19 05:29:19', ' ', '', '', 'publish', 'closed', 'closed', '', '59', '', '', '2019-01-27 04:17:26', '2019-01-27 04:17:26', '', 0, 'http://localhost/gctl/?p=59', 3, 'nav_menu_item', '', 0),
(60, 1, '2019-01-19 05:29:19', '2019-01-19 05:29:19', ' ', '', '', 'publish', 'closed', 'closed', '', '60', '', '', '2019-01-27 04:17:26', '2019-01-27 04:17:26', '', 0, 'http://localhost/gctl/?p=60', 4, 'nav_menu_item', '', 0),
(61, 1, '2019-01-19 05:29:20', '2019-01-19 05:29:20', ' ', '', '', 'publish', 'closed', 'closed', '', '61', '', '', '2019-01-27 04:17:26', '2019-01-27 04:17:26', '', 0, 'http://localhost/gctl/?p=61', 5, 'nav_menu_item', '', 0),
(62, 1, '2019-01-19 05:29:20', '2019-01-19 05:29:20', ' ', '', '', 'publish', 'closed', 'closed', '', '62', '', '', '2019-01-27 04:17:26', '2019-01-27 04:17:26', '', 0, 'http://localhost/gctl/?p=62', 2, 'nav_menu_item', '', 0),
(64, 1, '2019-01-19 05:39:57', '2019-01-19 05:39:57', '', 'Custom Home Page', '', 'publish', 'closed', 'closed', '', 'home-page', '', '', '2019-01-23 06:40:33', '2019-01-23 06:40:33', '', 0, 'http://localhost/gctl/?page_id=64', 0, 'page', '', 0),
(65, 1, '2019-01-19 05:39:57', '2019-01-19 05:39:57', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-19 05:39:57', '2019-01-19 05:39:57', '', 64, 'http://localhost/gctl/2019/01/19/64-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2019-01-19 05:50:19', '2019-01-19 05:50:19', '', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-19 05:50:19', '2019-01-19 05:50:19', '', 64, 'http://localhost/gctl/2019/01/19/64-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2019-01-19 10:58:25', '2019-01-19 10:58:25', '', 'Home', '', 'publish', 'closed', 'closed', '', '71', '', '', '2019-01-27 04:17:26', '2019-01-27 04:17:26', '', 0, 'http://localhost/gctl/?p=71', 1, 'nav_menu_item', '', 0),
(72, 1, '2019-01-19 11:43:43', '2019-01-19 11:43:43', '', 'Keys Case', '', 'inherit', 'open', 'closed', '', 'keys-case', '', '', '2019-01-19 11:43:43', '2019-01-19 11:43:43', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Keys-Case.png', 0, 'attachment', 'image/png', 0),
(73, 1, '2019-01-19 11:43:46', '2019-01-19 11:43:46', '', 'Laptop Bag', '', 'inherit', 'open', 'closed', '', 'laptop-bag', '', '', '2019-01-19 11:43:46', '2019-01-19 11:43:46', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Laptop-Bag.png', 0, 'attachment', 'image/png', 0),
(74, 1, '2019-01-19 11:43:47', '2019-01-19 11:43:47', '', 'Mens leather bag', '', 'inherit', 'open', 'closed', '', 'mens-leather-bag', '', '', '2019-01-19 11:43:47', '2019-01-19 11:43:47', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Mens-leather-bag.png', 0, 'attachment', 'image/png', 0),
(75, 1, '2019-01-19 11:43:48', '2019-01-19 11:43:48', '', 'Mens wallets', '', 'inherit', 'open', 'closed', '', 'mens-wallets', '', '', '2019-01-19 11:43:48', '2019-01-19 11:43:48', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Mens-wallets.png', 0, 'attachment', 'image/png', 0),
(76, 1, '2019-01-19 11:43:49', '2019-01-19 11:43:49', '', 'Pouches', '', 'inherit', 'open', 'closed', '', 'pouches', '', '', '2019-01-19 11:43:49', '2019-01-19 11:43:49', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Pouches.png', 0, 'attachment', 'image/png', 0),
(77, 1, '2019-01-19 11:43:50', '2019-01-19 11:43:50', '', 'Pouches2', '', 'inherit', 'open', 'closed', '', 'pouches2', '', '', '2019-01-19 11:43:50', '2019-01-19 11:43:50', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Pouches2.png', 0, 'attachment', 'image/png', 0),
(78, 1, '2019-01-19 11:43:51', '2019-01-19 11:43:51', '', 'PU Leather Bag', '', 'inherit', 'open', 'closed', '', 'pu-leather-bag', '', '', '2019-01-19 11:43:51', '2019-01-19 11:43:51', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/PU-Leather-Bag.png', 0, 'attachment', 'image/png', 0),
(79, 1, '2019-01-19 11:43:52', '2019-01-19 11:43:52', '', 'Travel wallets', '', 'inherit', 'open', 'closed', '', 'travel-wallets', '', '', '2019-01-19 11:43:52', '2019-01-19 11:43:52', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Travel-wallets.png', 0, 'attachment', 'image/png', 0),
(80, 1, '2019-01-19 11:43:53', '2019-01-19 11:43:53', '', 'Womens leather bag', '', 'inherit', 'open', 'closed', '', 'womens-leather-bag', '', '', '2019-01-19 11:43:53', '2019-01-19 11:43:53', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Womens-leather-bag.png', 0, 'attachment', 'image/png', 0),
(81, 1, '2019-01-19 11:43:54', '2019-01-19 11:43:54', '', 'Womens wallets', '', 'inherit', 'open', 'closed', '', 'womens-wallets', '', '', '2019-01-19 11:43:54', '2019-01-19 11:43:54', '', 0, 'http://localhost/gctl/wp-content/uploads/2019/01/Womens-wallets.png', 0, 'attachment', 'image/png', 0),
(82, 1, '2019-01-21 06:56:05', '2019-01-21 06:56:05', 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.', 'Cap', '<p>This is a simple product.</p>', 'inherit', 'closed', 'closed', '', '16-autosave-v1', '', '', '2019-01-21 06:56:05', '2019-01-21 06:56:05', '', 16, 'http://localhost/gctl/2019/01/21/16-autosave-v1/', 0, 'revision', '', 0),
(83, 1, '2019-01-22 05:27:46', '2019-01-22 05:27:46', '', 'Products One', '', 'inherit', 'open', 'closed', '', 'products-one', '', '', '2019-01-22 05:27:46', '2019-01-22 05:27:46', '', 16, 'http://localhost/gctl/wp-content/uploads/2019/01/Products-One.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 1, '2019-01-23 06:25:37', '2019-01-23 06:25:37', '<!-- wp:paragraph -->\n<p>[best_selling_products]</p>\n<!-- /wp:paragraph -->', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-23 06:25:37', '2019-01-23 06:25:37', '', 64, 'http://localhost/gctl/2019/01/23/64-revision-v1/', 0, 'revision', '', 0),
(86, 1, '2019-01-23 06:26:44', '2019-01-23 06:26:44', '<!-- wp:paragraph -->\n<p> <br>[products]<br></p>\n<!-- /wp:paragraph -->', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-23 06:26:44', '2019-01-23 06:26:44', '', 64, 'http://localhost/gctl/2019/01/23/64-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2019-01-23 06:27:47', '2019-01-23 06:27:47', '<!-- wp:paragraph -->\n<p>[products]<br></p>\n<!-- /wp:paragraph -->', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-23 06:27:47', '2019-01-23 06:27:47', '', 64, 'http://localhost/gctl/2019/01/23/64-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2019-01-23 06:32:22', '2019-01-23 06:32:22', '', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-23 06:32:22', '2019-01-23 06:32:22', '', 64, 'http://localhost/gctl/2019/01/23/64-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2019-01-23 06:32:35', '2019-01-23 06:32:35', '<!-- wp:html -->\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n<!-- /wp:html -->', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-23 06:32:35', '2019-01-23 06:32:35', '', 64, 'http://localhost/gctl/2019/01/23/64-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2019-01-23 06:33:16', '2019-01-23 06:33:16', '<!-- wp:preformatted -->\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n<!-- /wp:preformatted -->', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-23 06:33:16', '2019-01-23 06:33:16', '', 64, 'http://localhost/gctl/2019/01/23/64-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2019-01-23 06:34:20', '2019-01-23 06:34:20', '[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]\n\n[products limit=\"4\" columns=\"4\" orderby=\"popularity\" class=\"quick-sale\" on_sale=\"true\" ]', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-23 06:34:20', '2019-01-23 06:34:20', '', 64, 'http://localhost/gctl/2019/01/23/64-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2019-01-23 06:40:33', '2019-01-23 06:40:33', '', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2019-01-23 06:40:33', '2019-01-23 06:40:33', '', 64, 'http://localhost/gctl/2019/01/23/64-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2019-01-23 08:01:32', '2019-01-23 08:01:32', '<!-- wp:paragraph -->\n<p>/products</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Custom Home Page', '', 'inherit', 'closed', 'closed', '', '64-autosave-v1', '', '', '2019-01-23 08:01:32', '2019-01-23 08:01:32', '', 64, 'http://localhost/gctl/2019/01/23/64-autosave-v1/', 0, 'revision', '', 0),
(98, 1, '2019-01-26 09:48:23', '2019-01-26 09:48:23', '<p>[woocommerce_checkout]</p>\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'Checkout', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2019-01-26 09:48:23', '2019-01-26 09:48:23', '', 7, 'http://localhost/gctl/2019/01/26/7-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2019-01-26 12:04:03', '2019-01-26 12:04:03', '', 'Order &ndash; January 26, 2019 @ 12:04 PM', '', 'wc-on-hold', 'open', 'closed', 'wc_order_2cfx469keyBcR', 'order-jan-26-2019-1204-pm', '', '', '2019-01-26 12:04:09', '2019-01-26 12:04:09', '', 0, 'http://localhost/gctl/?post_type=shop_order&#038;p=99', 0, 'shop_order', '', 1),
(101, 1, '2019-01-27 04:16:34', '2019-01-27 04:16:34', '[woocommerce_cart]', 'Cart', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-01-27 04:16:34', '2019-01-27 04:16:34', '', 6, 'http://localhost/gctl/2019/01/27/6-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2019-01-27 10:43:33', '2019-01-27 10:43:33', '', 'Order &ndash; January 27, 2019 @ 10:43 AM', '', 'wc-on-hold', 'open', 'closed', 'wc_order_xFGtX5GOsFlli', 'order-jan-27-2019-1043-am', '', '', '2019-01-27 10:43:39', '2019-01-27 10:43:39', '', 0, 'http://localhost/gctl/?post_type=shop_order&#038;p=102', 0, 'shop_order', '', 1),
(103, 1, '2019-01-27 10:52:21', '2019-01-27 10:52:21', '', 'Order &ndash; January 27, 2019 @ 10:52 AM', '', 'wc-on-hold', 'open', 'closed', 'wc_order_bDw1nT3Uz5gmH', 'order-jan-27-2019-1052-am', '', '', '2019-01-27 10:52:23', '2019-01-27 10:52:23', '', 0, 'http://localhost/gctl/?post_type=shop_order&#038;p=103', 0, 'shop_order', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_queue`
--

CREATE TABLE `mmhs_wp_queue` (
  `id` bigint(20) NOT NULL,
  `job` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `locked_at` datetime DEFAULT NULL,
  `available_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_termmeta`
--

CREATE TABLE `mmhs_wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_termmeta`
--

INSERT INTO `mmhs_wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 15, 'product_count_product_cat', '0'),
(2, 16, 'order', '0'),
(3, 17, 'order', '0'),
(4, 18, 'order', '0'),
(5, 19, 'order', '0'),
(6, 20, 'order', '0'),
(7, 21, 'order', '0'),
(8, 17, 'product_count_product_cat', '5'),
(9, 16, 'product_count_product_cat', '14'),
(10, 22, 'order_pa_color', '0'),
(11, 23, 'order_pa_color', '0'),
(12, 24, 'order_pa_color', '0'),
(13, 25, 'order_pa_size', '0'),
(14, 26, 'order_pa_size', '0'),
(15, 27, 'order_pa_size', '0'),
(16, 18, 'product_count_product_cat', '3'),
(17, 28, 'order_pa_color', '0'),
(18, 19, 'product_count_product_cat', '5'),
(19, 29, 'order_pa_color', '0'),
(20, 20, 'product_count_product_cat', '2'),
(21, 21, 'product_count_product_cat', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_terms`
--

CREATE TABLE `mmhs_wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_terms`
--

INSERT INTO `mmhs_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Uncategorized', 'uncategorized', 0),
(16, 'Clothing', 'clothing', 0),
(17, 'Tshirts', 'tshirts', 0),
(18, 'Hoodies', 'hoodies', 0),
(19, 'Accessories', 'accessories', 0),
(20, 'Music', 'music', 0),
(21, 'Decor', 'decor', 0),
(22, 'Blue', 'blue', 0),
(23, 'Green', 'green', 0),
(24, 'Red', 'red', 0),
(25, 'Large', 'large', 0),
(26, 'Medium', 'medium', 0),
(27, 'Small', 'small', 0),
(28, 'Gray', 'gray', 0),
(29, 'Yellow', 'yellow', 0),
(30, 'Meha Menu', 'meha-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_term_relationships`
--

CREATE TABLE `mmhs_wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_term_relationships`
--

INSERT INTO `mmhs_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(10, 4, 0),
(10, 8, 0),
(10, 17, 0),
(10, 22, 0),
(10, 23, 0),
(10, 24, 0),
(10, 25, 0),
(10, 26, 0),
(10, 27, 0),
(11, 4, 0),
(11, 18, 0),
(11, 22, 0),
(11, 23, 0),
(11, 24, 0),
(12, 2, 0),
(12, 18, 0),
(12, 22, 0),
(13, 2, 0),
(13, 17, 0),
(13, 28, 0),
(14, 2, 0),
(14, 19, 0),
(14, 24, 0),
(15, 2, 0),
(15, 19, 0),
(16, 2, 0),
(16, 8, 0),
(16, 19, 0),
(16, 29, 0),
(17, 2, 0),
(17, 8, 0),
(17, 19, 0),
(18, 2, 0),
(18, 6, 0),
(18, 7, 0),
(18, 8, 0),
(18, 18, 0),
(18, 28, 0),
(19, 2, 0),
(19, 8, 0),
(19, 18, 0),
(20, 2, 0),
(20, 17, 0),
(20, 23, 0),
(21, 2, 0),
(21, 17, 0),
(21, 22, 0),
(22, 2, 0),
(22, 20, 0),
(23, 2, 0),
(23, 20, 0),
(24, 15, 0),
(25, 15, 0),
(26, 15, 0),
(27, 15, 0),
(28, 15, 0),
(29, 15, 0),
(30, 2, 0),
(30, 17, 0),
(30, 28, 0),
(31, 2, 0),
(31, 19, 0),
(31, 24, 0),
(32, 3, 0),
(32, 16, 0),
(33, 5, 0),
(33, 21, 0),
(34, 15, 0),
(59, 30, 0),
(60, 30, 0),
(61, 30, 0),
(62, 30, 0),
(71, 30, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_term_taxonomy`
--

CREATE TABLE `mmhs_wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_term_taxonomy`
--

INSERT INTO `mmhs_wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 14),
(3, 3, 'product_type', '', 0, 1),
(4, 4, 'product_type', '', 0, 2),
(5, 5, 'product_type', '', 0, 1),
(6, 6, 'product_visibility', '', 0, 1),
(7, 7, 'product_visibility', '', 0, 1),
(8, 8, 'product_visibility', '', 0, 5),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(16, 16, 'product_cat', '', 0, 1),
(17, 17, 'product_cat', '', 16, 5),
(18, 18, 'product_cat', '', 16, 4),
(19, 19, 'product_cat', '', 16, 5),
(20, 20, 'product_cat', '', 0, 2),
(21, 21, 'product_cat', '', 0, 1),
(22, 22, 'pa_color', '', 0, 4),
(23, 23, 'pa_color', '', 0, 3),
(24, 24, 'pa_color', '', 0, 4),
(25, 25, 'pa_size', '', 0, 1),
(26, 26, 'pa_size', '', 0, 1),
(27, 27, 'pa_size', '', 0, 1),
(28, 28, 'pa_color', '', 0, 3),
(29, 29, 'pa_color', '', 0, 1),
(30, 30, 'nav_menu', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_usermeta`
--

CREATE TABLE `mmhs_wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_usermeta`
--

INSERT INTO `mmhs_wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', 'Md. Mehedi Hassan'),
(3, 1, 'last_name', 'Sharif'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'mmhs_wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'mmhs_wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy,text_widget_custom_html'),
(15, 1, 'show_welcome_panel', '0'),
(17, 1, 'mmhs_wp_dashboard_quick_press_last_post_id', '84'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(20, 1, 'mmhs_wp_woocommerce_product_import_mapping', 'a:51:{i:0;s:2:\"id\";i:1;s:4:\"type\";i:2;s:3:\"sku\";i:3;s:4:\"name\";i:4;s:9:\"published\";i:5;s:8:\"featured\";i:6;s:18:\"catalog_visibility\";i:7;s:17:\"short_description\";i:8;s:11:\"description\";i:9;s:17:\"date_on_sale_from\";i:10;s:15:\"date_on_sale_to\";i:11;s:10:\"tax_status\";i:12;s:9:\"tax_class\";i:13;s:12:\"stock_status\";i:14;s:14:\"stock_quantity\";i:15;s:10:\"backorders\";i:16;s:17:\"sold_individually\";i:17;s:0:\"\";i:18;s:6:\"length\";i:19;s:5:\"width\";i:20;s:6:\"height\";i:21;s:15:\"reviews_allowed\";i:22;s:13:\"purchase_note\";i:23;s:10:\"sale_price\";i:24;s:13:\"regular_price\";i:25;s:12:\"category_ids\";i:26;s:7:\"tag_ids\";i:27;s:17:\"shipping_class_id\";i:28;s:6:\"images\";i:29;s:14:\"download_limit\";i:30;s:15:\"download_expiry\";i:31;s:9:\"parent_id\";i:32;s:16:\"grouped_products\";i:33;s:10:\"upsell_ids\";i:34;s:14:\"cross_sell_ids\";i:35;s:11:\"product_url\";i:36;s:11:\"button_text\";i:37;s:10:\"menu_order\";i:38;s:16:\"attributes:name1\";i:39;s:17:\"attributes:value1\";i:40;s:19:\"attributes:visible1\";i:41;s:20:\"attributes:taxonomy1\";i:42;s:16:\"attributes:name2\";i:43;s:17:\"attributes:value2\";i:44;s:19:\"attributes:visible2\";i:45;s:20:\"attributes:taxonomy2\";i:46;s:23:\"meta:_wpcom_is_markdown\";i:47;s:15:\"downloads:name1\";i:48;s:14:\"downloads:url1\";i:49;s:15:\"downloads:name2\";i:50;s:14:\"downloads:url2\";}'),
(21, 1, 'mmhs_wp_product_import_error_log', 'a:0:{}'),
(22, 1, 'wc_last_active', '1548547200'),
(23, 1, 'dismissed_wootenberg_notice', '1'),
(24, 1, 'dismissed_no_secure_connection_notice', '1'),
(25, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(26, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-product_cat\";i:3;s:15:\"add-product_tag\";}'),
(27, 1, 'nav_menu_recently_edited', '30'),
(28, 1, 'mmhs_wp_user-settings', 'libraryContent=browse&editor=html'),
(29, 1, 'mmhs_wp_user-settings-time', '1548247286'),
(30, 1, 'dismissed_template_files_notice', '1'),
(33, 1, 'billing_first_name', 'Md. Mehedi Hassan'),
(34, 1, 'billing_last_name', 'Sharif'),
(35, 1, 'billing_company', ''),
(36, 1, 'billing_address_1', 'House No - 43, Road No -10'),
(37, 1, 'billing_address_2', ''),
(38, 1, 'billing_city', 'Dhaka'),
(39, 1, 'billing_postcode', '2800'),
(40, 1, 'billing_country', 'BD'),
(41, 1, 'billing_state', 'BD-13'),
(42, 1, 'billing_phone', '+8801728443313'),
(43, 1, 'billing_email', 'mehedi00014@gmail.com'),
(44, 1, 'shipping_first_name', 'Md. Mehedi Hassan'),
(45, 1, 'shipping_last_name', 'Sharif'),
(46, 1, 'shipping_company', ''),
(47, 1, 'shipping_address_1', 'House No - 43, Road No -10'),
(48, 1, 'shipping_address_2', ''),
(49, 1, 'shipping_city', 'Dhaka'),
(50, 1, 'shipping_postcode', '2800'),
(51, 1, 'shipping_country', 'BD'),
(52, 1, 'shipping_state', 'BD-13'),
(53, 1, 'last_update', '1548586341'),
(54, 1, 'closedpostboxes_product', 'a:0:{}'),
(55, 1, 'metaboxhidden_product', 'a:2:{i:0;s:10:\"postcustom\";i:1;s:7:\"slugdiv\";}'),
(56, 1, 'shipping_method', ''),
(59, 1, 'session_tokens', 'a:1:{s:64:\"15a8c47bbcad63fea94e5904a3989421938adec42c197fc4d5ec92e81974b8ac\";a:4:{s:10:\"expiration\";i:1548758476;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0\";s:5:\"login\";i:1548585676;}}'),
(64, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:0:{}}');

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_users`
--

CREATE TABLE `mmhs_wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_users`
--

INSERT INTO `mmhs_wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BfuTZ0MoU2NC0jAP/d4IDpDwCgmNcX.', 'admin', 'mehedi00014@gmail.com', '', '2019-01-15 11:17:46', '', 0, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_wc_download_log`
--

CREATE TABLE `mmhs_wp_wc_download_log` (
  `download_log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_wc_webhooks`
--

CREATE TABLE `mmhs_wp_wc_webhooks` (
  `webhook_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_api_keys`
--

CREATE TABLE `mmhs_wp_woocommerce_api_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_attribute_taxonomies`
--

CREATE TABLE `mmhs_wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_woocommerce_attribute_taxonomies`
--

INSERT INTO `mmhs_wp_woocommerce_attribute_taxonomies` (`attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(1, 'color', 'Color', 'select', 'menu_order', 0),
(2, 'size', 'Size', 'select', 'menu_order', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_downloadable_product_permissions`
--

CREATE TABLE `mmhs_wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_log`
--

CREATE TABLE `mmhs_wp_woocommerce_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_order_itemmeta`
--

CREATE TABLE `mmhs_wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_woocommerce_order_itemmeta`
--

INSERT INTO `mmhs_wp_woocommerce_order_itemmeta` (`meta_id`, `order_item_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_product_id', '22'),
(2, 1, '_variation_id', '0'),
(3, 1, '_qty', '12'),
(4, 1, '_tax_class', ''),
(5, 1, '_line_subtotal', '180'),
(6, 1, '_line_subtotal_tax', '0'),
(7, 1, '_line_total', '180'),
(8, 1, '_line_tax', '0'),
(9, 1, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(10, 2, '_product_id', '14'),
(11, 2, '_variation_id', '0'),
(12, 2, '_qty', '3'),
(13, 2, '_tax_class', ''),
(14, 2, '_line_subtotal', '54'),
(15, 2, '_line_subtotal_tax', '0'),
(16, 2, '_line_total', '54'),
(17, 2, '_line_tax', '0'),
(18, 2, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(19, 3, '_product_id', '12'),
(20, 3, '_variation_id', '0'),
(21, 3, '_qty', '6'),
(22, 3, '_tax_class', ''),
(23, 3, '_line_subtotal', '270'),
(24, 3, '_line_subtotal_tax', '0'),
(25, 3, '_line_total', '270'),
(26, 3, '_line_tax', '0'),
(27, 3, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(28, 4, '_product_id', '11'),
(29, 4, '_variation_id', '34'),
(30, 4, '_qty', '7'),
(31, 4, '_tax_class', ''),
(32, 4, '_line_subtotal', '315'),
(33, 4, '_line_subtotal_tax', '0'),
(34, 4, '_line_total', '315'),
(35, 4, '_line_tax', '0'),
(36, 4, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(37, 4, 'pa_color', 'blue'),
(38, 4, 'logo', 'Yes'),
(39, 5, '_product_id', '11'),
(40, 5, '_variation_id', '28'),
(41, 5, '_qty', '5'),
(42, 5, '_tax_class', ''),
(43, 5, '_line_subtotal', '225'),
(44, 5, '_line_subtotal_tax', '0'),
(45, 5, '_line_total', '225'),
(46, 5, '_line_tax', '0'),
(47, 5, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(48, 5, 'pa_color', 'green'),
(49, 5, 'logo', 'No'),
(50, 6, '_product_id', '31'),
(51, 6, '_variation_id', '0'),
(52, 6, '_qty', '1'),
(53, 6, '_tax_class', ''),
(54, 6, '_line_subtotal', '18'),
(55, 6, '_line_subtotal_tax', '0'),
(56, 6, '_line_total', '18'),
(57, 6, '_line_tax', '0'),
(58, 6, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(59, 7, 'method_id', 'free_shipping'),
(60, 7, 'instance_id', '1'),
(61, 7, 'cost', '0.00'),
(62, 7, 'total_tax', '0'),
(63, 7, 'taxes', 'a:1:{s:5:\"total\";a:0:{}}'),
(64, 7, 'Items', 'Beanie &times; 3, Hoodie with Logo &times; 6, Hoodie - Blue, Yes &times; 7, Hoodie - Green, No &times; 5, Beanie with Logo &times; 1'),
(65, 8, '_product_id', '14'),
(66, 8, '_variation_id', '0'),
(67, 8, '_qty', '3'),
(68, 8, '_tax_class', ''),
(69, 8, '_line_subtotal', '54'),
(70, 8, '_line_subtotal_tax', '0'),
(71, 8, '_line_total', '54'),
(72, 8, '_line_tax', '0'),
(73, 8, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(74, 9, '_product_id', '16'),
(75, 9, '_variation_id', '0'),
(76, 9, '_qty', '2'),
(77, 9, '_tax_class', ''),
(78, 9, '_line_subtotal', '32'),
(79, 9, '_line_subtotal_tax', '0'),
(80, 9, '_line_total', '32'),
(81, 9, '_line_tax', '0'),
(82, 9, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(83, 10, '_product_id', '31'),
(84, 10, '_variation_id', '0'),
(85, 10, '_qty', '5'),
(86, 10, '_tax_class', ''),
(87, 10, '_line_subtotal', '90'),
(88, 10, '_line_subtotal_tax', '0'),
(89, 10, '_line_total', '90'),
(90, 10, '_line_tax', '0'),
(91, 10, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(92, 11, 'method_id', 'free_shipping'),
(93, 11, 'instance_id', '1'),
(94, 11, 'cost', '0.00'),
(95, 11, 'total_tax', '0'),
(96, 11, 'taxes', 'a:1:{s:5:\"total\";a:0:{}}'),
(97, 11, 'Items', 'Beanie &times; 3, Cap &times; 2, Beanie with Logo &times; 5'),
(98, 12, '_product_id', '22'),
(99, 12, '_variation_id', '0'),
(100, 12, '_qty', '6'),
(101, 12, '_tax_class', ''),
(102, 12, '_line_subtotal', '90'),
(103, 12, '_line_subtotal_tax', '0'),
(104, 12, '_line_total', '90'),
(105, 12, '_line_tax', '0'),
(106, 12, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}');

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_order_items`
--

CREATE TABLE `mmhs_wp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_woocommerce_order_items`
--

INSERT INTO `mmhs_wp_woocommerce_order_items` (`order_item_id`, `order_item_name`, `order_item_type`, `order_id`) VALUES
(1, 'Album', 'line_item', 99),
(2, 'Beanie', 'line_item', 99),
(3, 'Hoodie with Logo', 'line_item', 99),
(4, 'Hoodie - Blue, Yes', 'line_item', 99),
(5, 'Hoodie - Green, No', 'line_item', 99),
(6, 'Beanie with Logo', 'line_item', 99),
(7, 'Free shipping', 'shipping', 99),
(8, 'Beanie', 'line_item', 102),
(9, 'Cap', 'line_item', 102),
(10, 'Beanie with Logo', 'line_item', 102),
(11, 'Free shipping', 'shipping', 102),
(12, 'Album', 'line_item', 103);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_payment_tokenmeta`
--

CREATE TABLE `mmhs_wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `payment_token_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_payment_tokens`
--

CREATE TABLE `mmhs_wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_sessions`
--

CREATE TABLE `mmhs_wp_woocommerce_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_shipping_zones`
--

CREATE TABLE `mmhs_wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_woocommerce_shipping_zones`
--

INSERT INTO `mmhs_wp_woocommerce_shipping_zones` (`zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'Bangladesh', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_shipping_zone_locations`
--

CREATE TABLE `mmhs_wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_woocommerce_shipping_zone_locations`
--

INSERT INTO `mmhs_wp_woocommerce_shipping_zone_locations` (`location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'BD', 'country');

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_shipping_zone_methods`
--

CREATE TABLE `mmhs_wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `instance_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_woocommerce_shipping_zone_methods`
--

INSERT INTO `mmhs_wp_woocommerce_shipping_zone_methods` (`zone_id`, `instance_id`, `method_id`, `method_order`, `is_enabled`) VALUES
(1, 1, 'free_shipping', 1, 1),
(0, 2, 'free_shipping', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_tax_rates`
--

CREATE TABLE `mmhs_wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_woocommerce_tax_rates`
--

INSERT INTO `mmhs_wp_woocommerce_tax_rates` (`tax_rate_id`, `tax_rate_country`, `tax_rate_state`, `tax_rate`, `tax_rate_name`, `tax_rate_priority`, `tax_rate_compound`, `tax_rate_shipping`, `tax_rate_order`, `tax_rate_class`) VALUES
(1, 'GB', '', '20.0000', 'VAT', 1, 1, 1, 0, ''),
(2, 'GB', '', '5.0000', 'VAT', 1, 1, 1, 1, 'reduced-rate'),
(3, 'GB', '', '0.0000', 'VAT', 1, 1, 1, 2, 'zero-rate'),
(4, 'US', '', '10.0000', 'US', 1, 1, 1, 3, ''),
(5, 'US', 'AL', '2.0000', 'US AL', 2, 1, 1, 4, '');

-- --------------------------------------------------------

--
-- Table structure for table `mmhs_wp_woocommerce_tax_rate_locations`
--

CREATE TABLE `mmhs_wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mmhs_wp_woocommerce_tax_rate_locations`
--

INSERT INTO `mmhs_wp_woocommerce_tax_rate_locations` (`location_id`, `location_code`, `tax_rate_id`, `location_type`) VALUES
(1, '12345', 5, 'postcode'),
(2, '123456', 5, 'postcode');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mmhs_wp_commentmeta`
--
ALTER TABLE `mmhs_wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `mmhs_wp_comments`
--
ALTER TABLE `mmhs_wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Indexes for table `mmhs_wp_failed_jobs`
--
ALTER TABLE `mmhs_wp_failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mmhs_wp_links`
--
ALTER TABLE `mmhs_wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `mmhs_wp_options`
--
ALTER TABLE `mmhs_wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `mmhs_wp_postmeta`
--
ALTER TABLE `mmhs_wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `mmhs_wp_posts`
--
ALTER TABLE `mmhs_wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `mmhs_wp_queue`
--
ALTER TABLE `mmhs_wp_queue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mmhs_wp_termmeta`
--
ALTER TABLE `mmhs_wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `mmhs_wp_terms`
--
ALTER TABLE `mmhs_wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `mmhs_wp_term_relationships`
--
ALTER TABLE `mmhs_wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `mmhs_wp_term_taxonomy`
--
ALTER TABLE `mmhs_wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `mmhs_wp_usermeta`
--
ALTER TABLE `mmhs_wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `mmhs_wp_users`
--
ALTER TABLE `mmhs_wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `mmhs_wp_wc_download_log`
--
ALTER TABLE `mmhs_wp_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indexes for table `mmhs_wp_wc_webhooks`
--
ALTER TABLE `mmhs_wp_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `mmhs_wp_woocommerce_api_keys`
--
ALTER TABLE `mmhs_wp_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Indexes for table `mmhs_wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `mmhs_wp_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Indexes for table `mmhs_wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `mmhs_wp_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `mmhs_wp_woocommerce_log`
--
ALTER TABLE `mmhs_wp_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `mmhs_wp_woocommerce_order_itemmeta`
--
ALTER TABLE `mmhs_wp_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `mmhs_wp_woocommerce_order_items`
--
ALTER TABLE `mmhs_wp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `mmhs_wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `mmhs_wp_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `mmhs_wp_woocommerce_payment_tokens`
--
ALTER TABLE `mmhs_wp_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `mmhs_wp_woocommerce_sessions`
--
ALTER TABLE `mmhs_wp_woocommerce_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD UNIQUE KEY `session_key` (`session_key`);

--
-- Indexes for table `mmhs_wp_woocommerce_shipping_zones`
--
ALTER TABLE `mmhs_wp_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `mmhs_wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `mmhs_wp_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `mmhs_wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `mmhs_wp_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `mmhs_wp_woocommerce_tax_rates`
--
ALTER TABLE `mmhs_wp_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Indexes for table `mmhs_wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `mmhs_wp_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mmhs_wp_commentmeta`
--
ALTER TABLE `mmhs_wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_comments`
--
ALTER TABLE `mmhs_wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mmhs_wp_failed_jobs`
--
ALTER TABLE `mmhs_wp_failed_jobs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_links`
--
ALTER TABLE `mmhs_wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_options`
--
ALTER TABLE `mmhs_wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2371;

--
-- AUTO_INCREMENT for table `mmhs_wp_postmeta`
--
ALTER TABLE `mmhs_wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1310;

--
-- AUTO_INCREMENT for table `mmhs_wp_posts`
--
ALTER TABLE `mmhs_wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `mmhs_wp_queue`
--
ALTER TABLE `mmhs_wp_queue`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_termmeta`
--
ALTER TABLE `mmhs_wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `mmhs_wp_terms`
--
ALTER TABLE `mmhs_wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `mmhs_wp_term_taxonomy`
--
ALTER TABLE `mmhs_wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `mmhs_wp_usermeta`
--
ALTER TABLE `mmhs_wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `mmhs_wp_users`
--
ALTER TABLE `mmhs_wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mmhs_wp_wc_download_log`
--
ALTER TABLE `mmhs_wp_wc_download_log`
  MODIFY `download_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_wc_webhooks`
--
ALTER TABLE `mmhs_wp_wc_webhooks`
  MODIFY `webhook_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_api_keys`
--
ALTER TABLE `mmhs_wp_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `mmhs_wp_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `mmhs_wp_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_log`
--
ALTER TABLE `mmhs_wp_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_order_itemmeta`
--
ALTER TABLE `mmhs_wp_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_order_items`
--
ALTER TABLE `mmhs_wp_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `mmhs_wp_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_payment_tokens`
--
ALTER TABLE `mmhs_wp_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_sessions`
--
ALTER TABLE `mmhs_wp_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_shipping_zones`
--
ALTER TABLE `mmhs_wp_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `mmhs_wp_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `mmhs_wp_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_tax_rates`
--
ALTER TABLE `mmhs_wp_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mmhs_wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `mmhs_wp_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mmhs_wp_wc_download_log`
--
ALTER TABLE `mmhs_wp_wc_download_log`
  ADD CONSTRAINT `fk_mmhs_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `mmhs_wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
